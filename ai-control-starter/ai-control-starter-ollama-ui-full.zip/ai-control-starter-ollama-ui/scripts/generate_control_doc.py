import json
import argparse
from pathlib import Path

import model_client
from model_client import ModelClientError

CONTROL_DOC_SYSTEM = (
    "You are an expert project architect and technical lead.\n"
    "You will receive:\n"
    "- The raw project idea.\n"
    "- A JSON description of the virtual team and their questions.\n"
    "- A JSON file with the user's answers.\n\n"
    "Goal:\n"
    "- Generate a complete `control.md` for this project.\n"
    "Output ONLY valid Markdown.\n"
)


def main():
    ap = argparse.ArgumentParser(
        description="Generate a project-specific control.md from idea + Q&A JSON."
    )
    ap.add_argument("--idea", required=True, help="Path to idea.txt")
    ap.add_argument("--team", default="artifacts/team_and_questions_v0.1.json",
                    help="Path to team_and_questions JSON")
    ap.add_argument("--answers", default="artifacts/intake_answers_v0.1.json",
                    help="Path to filled intake answers JSON")
    ap.add_argument("--out", default="control.md", help="Where to write the Control Doc")
    args = ap.parse_args()

    idea_path = Path(args.idea)
    team_path = Path(args.team)
    answers_path = Path(args.answers)

    if not idea_path.exists():
        raise FileNotFoundError(f"Idea file not found: {idea_path}")
    if not team_path.exists():
        raise FileNotFoundError(f"Team JSON not found: {team_path}")
    if not answers_path.exists():
        raise FileNotFoundError(f"Answers JSON not found: {answers_path}")

    idea_text = idea_path.read_text(encoding="utf-8")
    team_data = json.loads(team_path.read_text(encoding="utf-8"))
    answers_data = json.loads(answers_path.read_text(encoding="utf-8"))

    combined_context = {
        "idea": idea_text,
        "team": team_data,
        "answers": answers_data,
    }

    user_prompt = (
        "Here is the combined JSON context for the project:\n\n"
        + json.dumps(combined_context, indent=2)
        + "\n\n"
        "Generate a `control.md` with sections:\n"
        "1. # Project Control Doc\n"
        "2. ## Objective (1–3 measurable bullets)\n"
        "3. ## Scope & Non-Goals\n"
        "4. ## Roles & Responsibilities\n"
        "5. ## Deliverables (D1, D2, ...)\n"
        "6. ## Task Graph (T1, T2, ... with dependencies)\n"
        "7. ## Interface Contracts (/schemas)\n"
        "8. ## Constraints\n"
        "9. ## Decision Log (seed with a few decisions)\n"
        "10. ## Open Questions\n"
    )

    try:
        control_md = model_client.generate_text(CONTROL_DOC_SYSTEM, user_prompt, task="planning")
    except ModelClientError as e:
        raise SystemExit(f"Error generating control.md: {e}")

    out_path = Path(args.out)
    out_path.write_text(control_md, encoding="utf-8")
    print(f"Wrote Control Doc to: {out_path}")


if __name__ == "__main__":
    main()
