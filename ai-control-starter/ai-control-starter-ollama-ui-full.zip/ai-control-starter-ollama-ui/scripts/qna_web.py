import json
from pathlib import Path

from flask import Flask, render_template, request, redirect, url_for, flash

import model_client
from model_client import ModelClientError

BASE_DIR = Path(__file__).resolve().parents[1]
ARTIFACTS_DIR = BASE_DIR / "artifacts"

IDEA_FILE = BASE_DIR / "idea.txt"
TEAM_FILE = ARTIFACTS_DIR / "team_and_questions_v0.1.json"
ANSWERS_FILE = ARTIFACTS_DIR / "intake_answers_v0.1.json"

app = Flask(__name__, template_folder=str(BASE_DIR / "templates"))
app.secret_key = "replace-this-secret-key"


def generate_team_and_questions(idea_text: str) -> dict:
    system_prompt = (
        "You are an AI project architect.\n"
        "Given a project idea, you must:\n"
        "- Create a list of roles.\n"
        "- For each role, include 3–7 high-value questions.\n"
        "- Include 3–10 global questions.\n"
        "Return ONLY valid JSON.\n"
    )

    user_prompt = (
        "Project idea:\n"
        "----------------------\n"
        + idea_text
        + "\n----------------------\n\n"
        "Return JSON in this shape:\n\n"
        "{\n"
        '  \"project_title\": \"string\",\n'
        '  \"summary\": \"string\",\n'
        '  \"roles\": [\n'
        "    {\n"
        '      \"id\": \"snake_case\",\n'
        '      \"label\": \"string\",\n'
        '      \"purpose\": \"string\",\n'
        '      \"questions\": [\n'
        "        {\"id\": \"string\", \"text\": \"string\", \"priority\": 1}\n"
        "      ]\n"
        "    }\n"
        "  ],\n"
        '  \"global_questions\": [\n'
        "    {\"id\": \"string\", \"text\": \"string\", \"priority\": 1}\n"
        "  ]\n"
        "}\n"
    )

    content = model_client.generate_text(system_prompt, user_prompt, task="planning").strip()

    if content.startswith("```"):
        content = content.strip("`")
        content = content.replace("json", "", 1).strip()

    return json.loads(content)


def load_team():
    if not TEAM_FILE.exists():
        raise FileNotFoundError("Team file does not exist. Submit an idea first.")
    return json.loads(TEAM_FILE.read_text(encoding="utf-8"))


def load_existing_answers(team):
    if ANSWERS_FILE.exists():
        data = json.loads(ANSWERS_FILE.read_text(encoding="utf-8"))
    else:
        data = {
            "project_title": team.get("project_title", ""),
            "summary": team.get("summary", ""),
            "answers": {},
            "global": [],
        }

    data.setdefault("answers", {})

    for role in team.get("roles", []):
        rid = role["id"]
        if rid not in data["answers"]:
            data["answers"][rid] = {
                "role_label": role["label"],
                "purpose": role["purpose"],
                "questions": [],
            }

        existing_by_id = {
            q["question_id"]: q
            for q in data["answers"][rid].get("questions", [])
        }

        merged_questions = []
        for q in role.get("questions", []):
            qid = q["id"]
            existing = existing_by_id.get(qid, {})
            merged_questions.append(
                {
                    "question_id": qid,
                    "question_text": q["text"],
                    "priority": q.get("priority", 1),
                    "answer": existing.get("answer", ""),
                }
            )
        data["answers"][rid]["questions"] = merged_questions

    existing_global = {g["question_id"]: g for g in data.get("global", [])}
    merged_global = []
    for gq in team.get("global_questions", []):
        qid = gq["id"]
        existing = existing_global.get(qid, {})
        merged_global.append(
            {
                "question_id": qid,
                "question_text": gq["text"],
                "priority": gq.get("priority", 1),
                "answer": existing.get("answer", ""),
            }
        )
    data["global"] = merged_global

    return data


@app.route("/", methods=["GET", "POST"])
def idea_form():
    existing_idea = ""
    if IDEA_FILE.exists():
        existing_idea = IDEA_FILE.read_text(encoding="utf-8")

    if request.method == "POST":
        idea_text = request.form.get("idea_text", "").strip()
        if not idea_text:
            flash("Please enter your idea.", "error")
            return render_template("idea_form.html", idea_text=existing_idea)

        IDEA_FILE.write_text(idea_text, encoding="utf-8")

        try:
            team_data = generate_team_and_questions(idea_text)
        except (ModelClientError, Exception) as e:
            flash(f"Error generating team/questions: {e}", "error")
            return render_template("idea_form.html", idea_text=idea_text)

        ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)
        TEAM_FILE.write_text(json.dumps(team_data, indent=2), encoding="utf-8")

        answers = {
            "project_title": team_data.get("project_title", ""),
            "summary": team_data.get("summary", ""),
            "answers": {},
            "global": [],
        }
        for role in team_data.get("roles", []):
            rid = role["id"]
            answers["answers"][rid] = {
                "role_label": role["label"],
                "purpose": role["purpose"],
                "questions": [
                    {
                        "question_id": q["id"],
                        "question_text": q["text"],
                        "priority": q.get("priority", 1),
                        "answer": "",
                    }
                    for q in role.get("questions", [])
                ],
            }
        for gq in team_data.get("global_questions", []):
            answers["global"].append(
                {
                    "question_id": gq["id"],
                    "question_text": gq["text"],
                    "priority": gq.get("priority", 1),
                    "answer": "",
                }
            )

        ANSWERS_FILE.write_text(json.dumps(answers, indent=2), encoding="utf-8")

        flash("Created team and questions from your idea. Now answer them.", "success")
        return redirect(url_for("qna_form"))

    return render_template("idea_form.html", idea_text=existing_idea)


@app.route("/questions", methods=["GET", "POST"])
def qna_form():
    try:
        team_data = load_team()
    except FileNotFoundError as e:
        flash(str(e), "error")
        return redirect(url_for("idea_form"))

    if request.method == "POST":
        answers_data = {
            "project_title": team_data.get("project_title", ""),
            "summary": team_data.get("summary", ""),
            "answers": {},
            "global": [],
        }

        for role in team_data.get("roles", []):
            rid = role["id"]
            qq = []
            for q in role.get("questions", []):
                qid = q["id"]
                field_name = f"{rid}__{qid}"
                answer = request.form.get(field_name, "").strip()
                qq.append(
                    {
                        "question_id": qid,
                        "question_text": q["text"],
                        "priority": q.get("priority", 1),
                        "answer": answer,
                    }
                )
            answers_data["answers"][rid] = {
                "role_label": role["label"],
                "purpose": role["purpose"],
                "questions": qq,
            }

        for gq in team_data.get("global_questions", []):
            qid = gq["id"]
            field_name = f"global__{qid}"
            answer = request.form.get(field_name, "").strip()
            answers_data["global"].append(
                {
                    "question_id": qid,
                    "question_text": gq["text"],
                    "priority": gq.get("priority", 1),
                    "answer": answer,
                }
            )

        ANSWERS_FILE.write_text(json.dumps(answers_data, indent=2), encoding="utf-8")
        flash("Saved answers.", "success")
        return redirect(url_for("qna_form"))

    answers_data = load_existing_answers(team_data)
    return render_template("qna_form.html", team=team_data, answers=answers_data)


if __name__ == "__main__":
    app.run(debug=True)
