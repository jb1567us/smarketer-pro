Texas Teacup Morkies Custom Theme (v1.1.2)

Highlights:
- Conversion-focused home page with Featured Puppy card.
- Custom post type: Puppies (Available / Reserved / Sold).
- Lead Mode toggle: Waitlist vs Referral (Appearance → TTP Settings).
- Local SEO pages created on activation (each includes directions map):
  Round Rock, Cedar Park, Bastrop, Pflugerville, Georgetown.
- Shortcodes:
  [ttp_map_directions] — embeds directions from an origin to the pickup address.
  [ttp_lead_cta] — CTA that auto-picks Apply vs Waitlist vs Referral.

If you need to rerun onboarding page creation:
- Delete `ttp_onboarding_done` from wp_options, then switch themes away and back.
