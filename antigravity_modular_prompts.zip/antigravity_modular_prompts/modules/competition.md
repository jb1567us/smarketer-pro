[SECTION:competition]
Section 5: Competitive Positioning (Key: competition)

Name 2–3 alternatives the buyer might consider.
If you’re not sure of exact brand names, use well-known category leaders OR describe competitor types.

For each competitor/alternative:
### Alternative {#} — {Name or Type}
- What it offers: 3–6 bullets
- Why buyers choose it: 3–6 bullets
- Weakness/gap for THIS buyer: 3–6 bullets
- Antigravity positioning:
  - Unique angle (1 sentence)
  - 3 differentiators (bullets)
  - “Steal-the-buyer” message (2–3 short lines)
  - Feature/benefit to emphasize first (and why)
- Partner advantage (if relevant): how partners make this product easier to adopt vs alternatives (2–4 bullets)
[/SECTION:competition]
