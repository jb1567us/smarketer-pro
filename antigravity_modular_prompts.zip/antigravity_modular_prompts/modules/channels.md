[SECTION:channels]
Section 3: Marketing Channel & Outreach Strategy (Key: channels)

Build a channel plan that includes:
A) direct acquisition channels (online/offline),
B) partner / channel-stream acquisition (affiliate + referral + reseller-like relationships),
C) targeted B2B email outreach strategy focused on product → pain points → outcomes,
D) local offline strategy: find “natural customers” in the physical area and place presence where they gather.

Required structure:

### Channel Plan — prioritized (Direct)
For each channel, include:
- Channel: {name}
- Best persona match: {which persona(s)}
- Why it works: 2–4 bullets
- Where exactly: specific communities/examples (subreddits, FB group types, LinkedIn groups/types, newsletters/types, events/types)
- Outreach tactic: 2–4 bullets (how to approach without being spammy)
- Messaging angle: 2–3 short hook lines
- First 7-day test: a small experiment with a measurable success signal

Include at least:
- 3–5 online channels
- 2–3 “dark social” channels (communities, group chats, Slack/Discord-style spaces)
- 2–3 offline channels (meetups, trade orgs, local events, conferences, retail/partner angles if relevant)

---

### Channel-Stream Partners — Affiliate / Referral / Reseller-style (Partner)
Identify 6–12 partner TYPES (and optionally 2–4 well-known examples if confident), that can reach the personas at scale.

For EACH partner type:
- Partner type: {e.g., agencies, consultants, distributors, managed service providers, communities, tool vendors, local businesses}
- Which persona(s) it reaches:
- Why they would care (partner pain points): 3–6 bullets (revenue, retention, differentiation, upsell)
- Partner offer design:
  - Affiliate model: suggested commission range and payout logic (one-time vs recurring) + why
  - Bundle model: what can be packaged together
  - Referral model: what qualifies as a “good lead”
- Co-marketing plan: 3–6 ideas (webinars, checklists, workshops, joint case studies)
- Partner enablement assets needed: 5–10 items (one-pager, pitch deck, demo, comparison sheet, email swipes, landing page, tracking links)
- Partner recruitment approach: where to find them + how to approach
- KPI to track: (leads, conversion rate, CAC, partner activation rate, revenue per partner)

---

### Targeted B2B Email Outreach Strategy (Product → Pain Point → Outcome)
Write an outreach sequence that targets businesses (B2B) as prospects AND a separate sequence that targets partner businesses for affiliate recruitment.

Provide:
1) Prospecting sequence (3 emails + 2 subject lines each)
- Email #1: pain-first, outcome-oriented, 120–170 words
- Email #2: proof + relevance, 90–140 words
- Email #3: breakup / close-the-loop, 60–110 words
For each email:
- Target: specify which persona/business type it’s for
- Personalization tokens: 3–6 bullets (what to reference to feel real)
- CTA: single low-friction ask

2) Partner recruitment sequence (2 emails + 2 subject lines each)
- Focus on partner economics + differentiation + easy activation
- Include a simple affiliate offer statement and next step

Constraints:
- No hype. No jargon. No “synergy.” No “revolutionary.”
- Make the product value explicit in the first 2 sentences.
- Tie every claim to a pain point and a measurable outcome when possible.

---

### Local Offline Strategy — “Where They Gather” Placement Plan
Design a local strategy for a business with a product/service to find natural customers nearby and reach them in physical spaces they already frequent.

Required structure:
- Local customer hypothesis (per persona): who is local, why local matters, what triggers local purchase
- “Where they gather” map: 8–15 physical gathering places/categories (worksites, associations, classes, shops, venues, orgs)
- Space-in-place tactic menu (choose 5–10):
  - Partnerships with venue owners
  - On-site demos/workshops
  - Referral swaps
  - Flyers/posters done ethically
  - Community boards
  - Sponsor a local league/club
  - Staff incentives at the gathering place
  - Co-host an event
  - Sampling/trials (if applicable)
- Outreach script (in-person or phone): 6–10 lines, respectful and specific
- Example adjacency plays: provide 5–10 examples like “gym → firefighters,” “pet groomer → dog breeders,” “yoga studio → physical therapists,” tailored to the product category if possible
- Measurement plan: what success looks like in 14 and 30 days (leads, foot traffic, referrals, trials)

[/SECTION:channels]
