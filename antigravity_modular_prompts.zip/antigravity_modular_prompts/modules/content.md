[SECTION:content]
Section 4: Content & SEO Strategy (Key: content)

Generate content ideas aligned to Awareness/Consideration/Decision,
AND include partner co-marketing content + an affiliate/partner content kit.

Required structure:
### Content Map
#### Top-of-funnel (Awareness) — 6 ideas
For each:
- Title:
- Audience/persona:
- Format: blog / video / short / checklist / template
- Core promise (1 sentence):
- Primary keyword:
- Secondary keywords (3–6):
- CTA: (soft CTA)

#### Mid-funnel (Consideration) — 6 ideas
Same fields, but include:
- Proof angle: what evidence you’ll show (demo, mini-case, benchmark, before/after)

#### Bottom-funnel (Decision) — 6 ideas
Same fields, but include:
- Objection handled: (which one)
- Proof asset: (what you’d include)

### Partner & Affiliate Content Kit (Enablement)
Create:
- 10 co-marketing content ideas partners would WANT to share (titles + 1-line angle)
- 6 “email swipe” snippets partners can copy/paste (2–4 lines each)
- 6 social post templates (short, non-hype)
- 3 landing page angles (headline + 3 bullets + CTA)
- 3 webinar/workshop outlines (agenda bullets)

### 90-day SEO focus
- Topic clusters: 3 clusters with 5–8 subtopics each
- Internal linking plan: 6–10 bullets
- “Money pages” to build: 3–6 pages (use-case, comparison, pricing explainer, etc.)
[/SECTION:content]
