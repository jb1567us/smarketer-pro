[SECTION:personas]
Section 1: Personas (Key: personas)

Create 2–3 ideal customer personas that best fit the product.

For EACH persona, use this structure:
### Persona {#} — {Name} ({Persona label})
- Snapshot: 1 sentence describing who they are + why they care.
- Demographics: age range, job title/role, industry, location, income/budget sensitivity (if relevant)
- Psychographics: values, motivations, identity signals, decision triggers, skepticism points
- Behavioral traits:
  - Buying style (fast/slow, consensus/solo, risk tolerance)
  - Research habits (what they read/watch, how they compare tools)
  - Tech comfort (low/medium/high) + tool stack they already use
- Pain points (top 3–5): phrased as “I need to…” or “I’m stuck because…”
- Core goals (top 3–5): measurable where possible
- Purchase role: user / decision-maker / influencer / gatekeeper + why
- “If you say X, I lean in”: 2–3 messaging hooks (short, punchy lines)
- “If you say Y, I bounce”: 2–3 messaging landmines
- Partner adjacency (who already sells to them): list 5–10 business types that already reach this persona and could be potential channel/affiliate partners (e.g., agencies, distributors, consultants, communities, vendors, service providers).

Assumptions must be labeled.
[/SECTION:personas]
