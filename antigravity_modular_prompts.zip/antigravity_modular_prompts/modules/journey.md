[SECTION:journey]
Section 2: Buyer Journey Mapping (Key: journey)

Map Awareness → Consideration → Decision for EACH persona from the Personas section.
Include both online AND offline touchpoints, plus partner influence.

For EACH persona, use:
### Journey — {Persona Name}
#### Awareness
- Situation: what’s happening in their world that creates the problem
- Thoughts: 3–5 bullets
- Feelings: 2–4 bullets
- Actions: 3–5 bullets (what they do first)
- Content needs: 3–6 items (format + topic)
- Search phrases: 5–10 realistic queries they might type
- Offline touchpoints: 3–6 places they physically go or communities they attend (worksites, stores, meetups, orgs)
- Partner influence: which partner types could introduce the solution at this stage and how

#### Consideration
- What “good enough” looks like
- Objections: 4–8 bullets
- Evaluation criteria: 5–9 bullets
- Comparison set: what categories/tools they compare against (types are okay)
- Content needs: 4–7 items (include proof assets: demos, case studies, calculators, etc.)
- Offline validation: what would they want to see locally (demo, trial, referral, workshop)
- Partner influence: what partners can provide (trust, bundling, services, onboarding)

#### Decision
- Decision triggers: 3–6 bullets (what finally tips them)
- Deal killers: 3–6 bullets
- Proof required: 3–6 bullets (social proof, ROI, security, guarantees, etc.)
- Best CTA style: 2–3 bullets (trial/demo/consult/etc.) + why
- Local closing path: 2–4 ways a local presence/placement/relationship could close faster
- Partner-assisted close: 2–4 ways a partner can reduce risk and accelerate purchase
[/SECTION:journey]
