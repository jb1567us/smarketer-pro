# Antigravity Modular Prompt Pack (Google AI Studio / Gemini)

This ZIP contains a modular, parse-friendly prompt system for a broad-use customer discovery app.

## Files
- `SYSTEM_PROMPT.txt` — paste into Google AI Studio "System" instruction.
- `USER_PROMPT_TEMPLATE.txt` — base user prompt with variables.
- `modules/` — section modules (append only the ones requested):
  - `personas.md`
  - `journey.md`
  - `channels.md` (includes partner/affiliate + B2B email outreach + local offline strategy)
  - `content.md` (includes partner/affiliate enablement kit)
  - `competition.md`

## Output contract (for parsing)
Each requested section MUST be wrapped like:
- `## Section Name (key)`
- `<!--BEGIN:key-->`
- content
- `<!--END:key-->`

Only include keys requested.

## Typical build order
`personas → journey → channels → content → competition`

## Suggested section keys
- personas
- journey
- channels
- content
- competition

Generated: 2025-12-27 19:54:50Z
