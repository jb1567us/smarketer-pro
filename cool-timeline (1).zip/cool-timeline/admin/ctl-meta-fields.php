<?php
class CoolTimelineMetaFields {
    
    public function __construct() {
        add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ) );
        add_action( 'save_post', array( $this, 'save_meta_fields' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
    }
    
    public function add_meta_boxes() {
        add_meta_box(
            'ctl_story_meta',
            'Timeline Story Details',
            array( $this, 'render_story_meta_fields' ),
            'cool_timeline',
            'normal',
            'high'
        );
        
        add_meta_box(
            'ctl_media_meta',
            'Media & Attachments',
            array( $this, 'render_media_meta_fields' ),
            'cool_timeline',
            'normal',
            'high'
        );

        add_meta_box(
            'ctl_research_meta',
            'Research & Collaboration',
            array( $this, 'render_research_meta_fields' ),
            'cool_timeline',
            'side',
            'high'
        );
    }
    
    public function render_story_meta_fields( $post ) {
        wp_nonce_field( 'ctl_save_meta', 'ctl_meta_nonce' );
        
        $story_date = get_post_meta( $post->ID, 'ctl_story_date', true );
        $location = get_post_meta( $post->ID, 'ctl_story_location', true );
        $source = get_post_meta( $post->ID, 'ctl_story_source', true );
        $importance = get_post_meta( $post->ID, 'ctl_story_importance', true );
        $research_status = get_post_meta( $post->ID, 'ctl_research_status', true );
        ?>
        <div class="ctl-meta-fields-container">
            <div class="ctl-field-group">
                <label for="ctl_story_date"><strong>📅 Story Date:</strong></label>
                <input type="date" id="ctl_story_date" name="ctl_story_date" value="<?php echo esc_attr( $story_date ); ?>" class="widefat" />
                <p class="description">The historical date for this event</p>
            </div>
            
            <div class="ctl-field-group">
                <label for="ctl_story_location"><strong>📍 Location:</strong></label>
                <input type="text" id="ctl_story_location" name="ctl_story_location" value="<?php echo esc_attr( $location ); ?>" class="widefat" placeholder="City, Country, Region" />
                <p class="description">Where this event took place</p>
            </div>
            
            <div class="ctl-field-group">
                <label for="ctl_story_source"><strong>📚 Sources & References:</strong></label>
                <textarea id="ctl_story_source" name="ctl_story_source" class="widefat" rows="4" placeholder="Family records, historical documents, photographs, oral history..."><?php echo esc_textarea( $source ); ?></textarea>
                <p class="description">Document your sources for historical accuracy</p>
            </div>
        </div>
        <?php
    }

    public function render_research_meta_fields( $post ) {
        $importance = get_post_meta( $post->ID, 'ctl_story_importance', true );
        $research_status = get_post_meta( $post->ID, 'ctl_research_status', true );
        $collaboration_notes = get_post_meta( $post->ID, 'ctl_collaboration_notes', true );
        
        if ( empty( $importance ) ) $importance = 'significant';
        if ( empty( $research_status ) ) $research_status = 'needs_research';
        ?>
        <div class="ctl-research-fields">
            <div class="ctl-field-group">
                <label for="ctl_story_importance"><strong>⭐ Historical Importance:</strong></label>
                <select id="ctl_story_importance" name="ctl_story_importance" class="widefat">
                    <option value="minor" <?php selected( $importance, 'minor' ); ?>>🔹 Minor Event</option>
                    <option value="significant" <?php selected( $importance, 'significant' ); ?>>🔸 Significant Event</option>
                    <option value="major" <?php selected( $importance, 'major' ); ?>>🔺 Major Life Event</option>
                    <option value="turning_point" <?php selected( $importance, 'turning_point' ); ?>>⭐ Life Turning Point</option>
                </select>
                <p class="description">How important was this event in the overall life story?</p>
            </div>
            
            <div class="ctl-field-group">
                <label for="ctl_research_status"><strong>🔍 Research Status:</strong></label>
                <select id="ctl_research_status" name="ctl_research_status" class="widefat">
                    <option value="needs_research" <?php selected( $research_status, 'needs_research' ); ?>>🟥 Needs Research</option>
                    <option value="in_progress" <?php selected( $research_status, 'in_progress' ); ?>>🟨 Research in Progress</option>
                    <option value="verified" <?php selected( $research_status, 'verified' ); ?>>🟦 Verified</option>
                    <option value="complete" <?php selected( $research_status, 'complete' ); ?>>🟩 Research Complete</option>
                </select>
                <p class="description">Track your research progress</p>
            </div>

            <div class="ctl-field-group">
                <label for="ctl_collaboration_notes"><strong>💬 Collaboration Notes:</strong></label>
                <textarea id="ctl_collaboration_notes" name="ctl_collaboration_notes" class="widefat" rows="3" placeholder="Notes for your co-author, questions to research, ideas..."><?php echo esc_textarea( $collaboration_notes ); ?></textarea>
                <p class="description">Private notes for your book collaboration</p>
            </div>

            <div class="ctl-research-stats">
                <h4>📊 Research Statistics</h4>
                <div class="ctl-stats-grid">
                    <div class="ctl-stat">
                        <span class="ctl-stat-number"><?php echo $this->get_word_count( $post->post_content ); ?></span>
                        <span class="ctl-stat-label">Words</span>
                    </div>
                    <div class="ctl-stat">
                        <span class="ctl-stat-number"><?php echo $this->get_media_count( $post->ID ); ?></span>
                        <span class="ctl-stat-label">Media Items</span>
                    </div>
                    <div class="ctl-stat">
                        <span class="ctl-stat-number"><?php echo $this->get_revision_count( $post->ID ); ?></span>
                        <span class="ctl-stat-label">Revisions</span>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    public function render_media_meta_fields( $post ) {
        wp_nonce_field( 'ctl_save_media', 'ctl_media_nonce' );
        
        $gallery_images = get_post_meta( $post->ID, 'ctl_gallery_images', true );
        $video_url = get_post_meta( $post->ID, 'ctl_video_url', true );
        $file_attachments = get_post_meta( $post->ID, 'ctl_file_attachments', true );
        ?>
        <div class="ctl-media-fields">
            
            <div class="ctl-field-group">
                <h3>🖼️ Gallery Images</h3>
                <div class="ctl-gallery-uploader">
                    <div class="ctl-gallery-preview" id="ctl_gallery_preview">
                        <?php
                        if ( ! empty( $gallery_images ) && is_array( $gallery_images ) ) {
                            foreach ( $gallery_images as $image_id ) {
                                if ( wp_attachment_is_image( $image_id ) ) {
                                    echo '<div class="ctl-gallery-thumb" data-id="' . esc_attr( $image_id ) . '">';
                                    echo wp_get_attachment_image( $image_id, 'thumbnail' );
                                    echo '<button type="button" class="ctl-remove-image" title="Remove image">×</button>';
                                    echo '</div>';
                                }
                            }
                        }
                        ?>
                    </div>
                    <input type="hidden" id="ctl_gallery_images" name="ctl_gallery_images" value="<?php echo esc_attr( is_array( $gallery_images ) ? implode( ',', $gallery_images ) : '' ); ?>">
                    <button type="button" class="button ctl-add-gallery-images">
                        <span class="dashicons dashicons-format-gallery"></span>
                        Add Gallery Images
                    </button>
                    <p class="description">Add multiple historical photos or documents. Maximum 10 images per story.</p>
                </div>
            </div>
            
            <div class="ctl-field-group">
                <h3>🎬 Video Content</h3>
                <label for="ctl_video_url">Video URL:</label>
                <input type="url" id="ctl_video_url" name="ctl_video_url" value="<?php echo esc_attr( $video_url ); ?>" class="widefat" placeholder="https://www.youtube.com/watch?v=..." />
                <p class="description">Enter YouTube, Vimeo, or self-hosted video URL. Supports MP4, WebM, OGG files.</p>
                
                <?php if ( ! empty( $video_url ) ) : ?>
                    <div class="ctl-video-preview">
                        <strong>Video Preview:</strong>
                        <div class="ctl-video-preview-embed">
                            <?php
                            $embed_code = wp_oembed_get( $video_url );
                            if ( $embed_code ) {
                                echo $embed_code;
                            } else {
                                echo '<p><em>Unable to preview this video URL. It will still work on the frontend.</em></p>';
                            }
                            ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="ctl-field-group">
                <h3>📎 File Attachments</h3>
                <div class="ctl-file-uploader">
                    <div class="ctl-file-preview" id="ctl_file_preview">
                        <?php
                        if ( ! empty( $file_attachments ) && is_array( $file_attachments ) ) {
                            foreach ( $file_attachments as $file_id ) {
                                $file_url = wp_get_attachment_url( $file_id );
                                $file_name = get_the_title( $file_id );
                                $file_type = get_post_mime_type( $file_id );
                                if ( $file_url ) {
                                    echo '<div class="ctl-file-item" data-id="' . esc_attr( $file_id ) . '">';
                                    echo '<span class="ctl-file-icon">' . $this->get_file_icon( $file_type ) . '</span>';
                                    echo '<span class="ctl-file-name">' . esc_html( $file_name ) . '</span>';
                                    echo '<span class="ctl-file-type">(' . $this->get_file_type_name( $file_type ) . ')</span>';
                                    echo '<button type="button" class="ctl-remove-file" title="Remove file">×</button>';
                                    echo '</div>';
                                }
                            }
                        }
                        ?>
                    </div>
                    <input type="hidden" id="ctl_file_attachments" name="ctl_file_attachments" value="<?php echo esc_attr( is_array( $file_attachments ) ? implode( ',', $file_attachments ) : '' ); ?>">
                    <button type="button" class="button ctl-add-files">
                        <span class="dashicons dashicons-media-document"></span>
                        Add File Attachments
                    </button>
                    <p class="description">Attach PDFs, documents, scans, or other research files. Perfect for book research.</p>
                </div>
            </div>
            
        </div>
        
        <style>
        .ctl-meta-fields-container,
        .ctl-research-fields,
        .ctl-media-fields { 
            margin: 15px 0; 
        }
        .ctl-field-group { 
            margin-bottom: 25px; 
            padding-bottom: 15px; 
            border-bottom: 1px solid #ccd0d4; 
        }
        .ctl-field-group:last-child {
            border-bottom: none;
        }
        .ctl-field-group h3 { 
            margin-bottom: 10px; 
            color: #23282d;
            font-size: 1.1em;
        }
        .ctl-field-group label {
            font-weight: 600;
            display: block;
            margin-bottom: 5px;
        }
        .description {
            font-style: italic;
            color: #666;
            margin-top: 5px;
        }
        
        /* Gallery Styles */
        .ctl-gallery-preview, .ctl-file-preview { 
            display: flex; 
            flex-wrap: wrap; 
            gap: 10px; 
            margin: 10px 0; 
            min-height: 60px;
            padding: 10px;
            background: #f9f9f9;
            border-radius: 4px;
        }
        .ctl-gallery-thumb { 
            position: relative; 
            border: 1px solid #ccd0d4; 
            padding: 5px; 
            background: #fff;
            border-radius: 4px;
        }
        .ctl-gallery-thumb img { 
            display: block; 
            max-width: 100px; 
            height: auto; 
        }
        .ctl-remove-image, .ctl-remove-file { 
            position: absolute; 
            top: -8px; 
            right: -8px; 
            background: #d63638; 
            color: white; 
            border: none; 
            border-radius: 50%; 
            width: 20px; 
            height: 20px; 
            cursor: pointer; 
            font-size: 14px;
            line-height: 1;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .ctl-remove-image:hover, .ctl-remove-file:hover {
            background: #a00;
        }
        
        /* File Styles */
        .ctl-file-item { 
            position: relative;
            padding: 8px 12px; 
            display: flex; 
            align-items: center; 
            gap: 8px; 
            border: 1px solid #ccd0d4;
            background: #fff;
            border-radius: 4px;
            min-width: 200px;
        }
        .ctl-file-icon {
            font-size: 16px;
        }
        .ctl-file-name {
            flex: 1;
            font-weight: 500;
        }
        .ctl-file-type {
            font-size: 0.8em;
            color: #666;
        }
        
        /* Video Preview */
        .ctl-video-preview {
            margin-top: 10px;
            padding: 10px;
            background: #f9f9f9;
            border-radius: 4px;
        }
        .ctl-video-preview-embed iframe {
            max-width: 100%;
        }
        
        /* Research Stats */
        .ctl-research-stats {
            margin-top: 20px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 4px;
        }
        .ctl-research-stats h4 {
            margin: 0 0 15px 0;
            color: #23282d;
        }
        .ctl-stats-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
        }
        .ctl-stat {
            text-align: center;
            padding: 10px;
            background: white;
            border-radius: 4px;
            border: 1px solid #e1e1e1;
        }
        .ctl-stat-number {
            display: block;
            font-size: 1.5em;
            font-weight: bold;
            color: #007cba;
        }
        .ctl-stat-label {
            font-size: 0.8em;
            color: #666;
            text-transform: uppercase;
        }
        
        /* Buttons */
        .ctl-add-gallery-images,
        .ctl-add-files {
            margin-top: 10px;
        }
        .button .dashicons {
            margin-right: 5px;
            vertical-align: middle;
        }
        </style>
        <?php
    }
    
    public function enqueue_admin_scripts( $hook ) {
        if ( 'post.php' !== $hook && 'post-new.php' !== $hook ) {
            return;
        }
        
        global $post_type;
        if ( 'cool_timeline' !== $post_type ) {
            return;
        }
        
        wp_enqueue_media();
        wp_enqueue_script( 
            'ctl-admin-media', 
            CTL_PLUGIN_URL . 'assets/js/admin-media.js', 
            array( 'jquery' ), 
            CTL_V, 
            true 
        );
    }
    
    public function save_meta_fields( $post_id ) {
        if ( ! isset( $_POST['ctl_meta_nonce'] ) || ! wp_verify_nonce( $_POST['ctl_meta_nonce'], 'ctl_save_meta' ) ) {
            return;
        }
        
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        
        if ( 'cool_timeline' !== get_post_type( $post_id ) ) {
            return;
        }
        
        // Save basic story fields
        $basic_fields = array(
            'ctl_story_date',
            'ctl_story_location',
            'ctl_story_source'
        );
        
        foreach ( $basic_fields as $field ) {
            if ( isset( $_POST[$field] ) ) {
                update_post_meta( $post_id, $field, sanitize_text_field( $_POST[$field] ) );
            }
        }
        
        // Save research fields
        $research_fields = array(
            'ctl_story_importance',
            'ctl_research_status',
            'ctl_collaboration_notes'
        );
        
        foreach ( $research_fields as $field ) {
            if ( isset( $_POST[$field] ) ) {
                update_post_meta( $post_id, $field, sanitize_text_field( $_POST[$field] ) );
            }
        }
        
        // Save media fields
        if ( isset( $_POST['ctl_gallery_images'] ) ) {
            $gallery_images = array_filter( array_map( 'intval', explode( ',', $_POST['ctl_gallery_images'] ) ) );
            update_post_meta( $post_id, 'ctl_gallery_images', $gallery_images );
        } else {
            delete_post_meta( $post_id, 'ctl_gallery_images' );
        }
        
        if ( isset( $_POST['ctl_video_url'] ) ) {
            update_post_meta( $post_id, 'ctl_video_url', esc_url_raw( $_POST['ctl_video_url'] ) );
        } else {
            delete_post_meta( $post_id, 'ctl_video_url' );
        }
        
        if ( isset( $_POST['ctl_file_attachments'] ) ) {
            $file_attachments = array_filter( array_map( 'intval', explode( ',', $_POST['ctl_file_attachments'] ) ) );
            update_post_meta( $post_id, 'ctl_file_attachments', $file_attachments );
        } else {
            delete_post_meta( $post_id, 'ctl_file_attachments' );
        }
    }
    
    // Helper methods for research statistics
    private function get_word_count( $content ) {
        return str_word_count( strip_tags( $content ) );
    }
    
    private function get_media_count( $post_id ) {
        $count = 0;
        
        if ( has_post_thumbnail( $post_id ) ) {
            $count++;
        }
        
        $gallery_images = get_post_meta( $post_id, 'ctl_gallery_images', true );
        if ( ! empty( $gallery_images ) && is_array( $gallery_images ) ) {
            $count += count( $gallery_images );
        }
        
        $file_attachments = get_post_meta( $post_id, 'ctl_file_attachments', true );
        if ( ! empty( $file_attachments ) && is_array( $file_attachments ) ) {
            $count += count( $file_attachments );
        }
        
        $video_url = get_post_meta( $post_id, 'ctl_video_url', true );
        if ( ! empty( $video_url ) ) {
            $count++;
        }
        
        return $count;
    }
    
    private function get_revision_count( $post_id ) {
        $revisions = wp_get_post_revisions( $post_id );
        return count( $revisions );
    }
    
    private function get_file_icon( $mime_type ) {
        $icons = array(
            'application/pdf' => '📄',
            'application/msword' => '📝',
            'application/vnd.ms-excel' => '📊',
            'application/zip' => '📦',
            'text/plain' => '📃',
            'image/' => '🖼️',
            'video/' => '🎬',
            'audio/' => '🎵'
        );
        
        foreach ( $icons as $key => $icon ) {
            if ( strpos( $mime_type, $key ) === 0 ) {
                return $icon;
            }
        }
        
        return '📎';
    }
    
    private function get_file_type_name( $mime_type ) {
        $types = array(
            'application/pdf' => 'PDF',
            'application/msword' => 'Word Doc',
            'application/vnd.ms-excel' => 'Excel',
            'application/zip' => 'ZIP',
            'text/plain' => 'Text',
            'image/jpeg' => 'JPEG',
            'image/png' => 'PNG',
            'image/gif' => 'GIF',
            'video/mp4' => 'MP4 Video',
            'audio/mpeg' => 'MP3 Audio'
        );
        
        return $types[$mime_type] ?? 'File';
    }
}

new CoolTimelineMetaFields();