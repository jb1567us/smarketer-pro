<?php
class CoolTimelineExport {
    
    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_export_page' ) );
        add_action( 'admin_init', array( $this, 'handle_export' ) );
    }
    
    public function add_export_page() {
        add_submenu_page(
            'cool_timeline_settings',
            'Export for Book',
            'Book Export',
            'manage_options',
            'ctl_export',
            array( $this, 'render_export_page' )
        );
    }
    
    public function render_export_page() {
        ?>
        <div class="wrap">
            <h1>Export for Book Publication</h1>
            
            <div class="ctl-export-options">
                <div class="ctl-export-card">
                    <h3>📖 Book Chapter Export</h3>
                    <p>Export timeline stories as formatted chapters for your book.</p>
                    <form method="post">
                        <?php wp_nonce_field( 'ctl_export_book', 'ctl_export_nonce' ); ?>
                        <input type="hidden" name="ctl_export_type" value="book">
                        
                        <div class="ctl-export-fields">
                            <div>
                                <label>Book Title:</label>
                                <input type="text" name="book_title" value="The Life of José Sancha Padrós" required>
                            </div>
                            <div>
                                <label>Author Name:</label>
                                <input type="text" name="author_name" value="<?php echo esc_attr( wp_get_current_user()->display_name ); ?>" required>
                            </div>
                            <div>
                                <label>Date Range:</label>
                                <select name="date_range">
                                    <option value="all">All Dates</option>
                                    <option value="custom">Custom Range</option>
                                </select>
                            </div>
                            <div>
                                <label>Include Media Captions:</label>
                                <input type="checkbox" name="include_captions" checked>
                            </div>
                        </div>
                        
                        <button type="submit" class="button button-primary">Generate Book Manuscript</button>
                    </form>
                </div>
                
                <div class="ctl-export-card">
                    <h3>📊 Research Summary</h3>
                    <p>Generate a research summary with statistics.</p>
                    <form method="post">
                        <?php wp_nonce_field( 'ctl_export_summary', 'ctl_export_nonce' ); ?>
                        <input type="hidden" name="ctl_export_type" value="summary">
                        <button type="submit" class="button">Generate Research Summary</button>
                    </form>
                </div>
                
                <div class="ctl-export-card">
                    <h3>📅 Timeline Overview</h3>
                    <p>Create a chronological overview for editors.</p>
                    <form method="post">
                        <?php wp_nonce_field( 'ctl_export_timeline', 'ctl_export_nonce' ); ?>
                        <input type="hidden" name="ctl_export_type" value="timeline">
                        <button type="submit" class="button">Generate Timeline Overview</button>
                    </form>
                </div>
            </div>
            
            <style>
            .ctl-export-options {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 20px;
                margin-top: 30px;
            }
            .ctl-export-card {
                background: white;
                padding: 25px;
                border-radius: 8px;
                border: 1px solid #ccd0d4;
            }
            .ctl-export-card h3 {
                margin-top: 0;
                color: #23282d;
            }
            .ctl-export-fields {
                display: grid;
                gap: 15px;
                margin: 20px 0;
            }
            .ctl-export-fields label {
                font-weight: bold;
                display: block;
                margin-bottom: 5px;
            }
            .ctl-export-fields input, 
            .ctl-export-fields select {
                width: 100%;
                padding: 8px;
            }
            </style>
        </div>
        <?php
    }
    
    public function handle_export() {
        if ( ! isset( $_POST['ctl_export_nonce'] ) ) {
            return;
        }
        
        if ( ! wp_verify_nonce( $_POST['ctl_export_nonce'], 'ctl_export_book' ) ) {
            return;
        }
        
        $export_type = $_POST['ctl_export_type'] ?? '';
        
        switch ( $export_type ) {
            case 'book':
                $this->export_book_manuscript();
                break;
            case 'summary':
                $this->export_research_summary();
                break;
            case 'timeline':
                $this->export_timeline_overview();
                break;
        }
    }
    
    private function export_book_manuscript() {
        $stories = $this->get_all_stories();
        
        header( 'Content-Type: text/plain' );
        header( 'Content-Disposition: attachment; filename="book-manuscript.txt"' );
        
        echo "BOOK MANUSCRIPT\n";
        echo "================\n\n";
        echo "Title: " . sanitize_text_field( $_POST['book_title'] ) . "\n";
        echo "Author: " . sanitize_text_field( $_POST['author_name'] ) . "\n";
        echo "Generated: " . date( 'F j, Y' ) . "\n\n";
        
        foreach ( $stories as $story ) {
            echo "CHAPTER: " . $story->post_title . "\n";
            echo "Date: " . get_post_meta( $story->ID, 'ctl_story_date', true ) . "\n";
            echo "----------------------------------------\n";
            echo wp_strip_all_tags( $story->post_content ) . "\n\n";
            
            // Include media notes if requested
            if ( isset( $_POST['include_captions'] ) ) {
                $media = $this->get_story_media( $story->ID );
                if ( ! empty( $media ) ) {
                    echo "MEDIA REFERENCES:\n";
                    foreach ( $media as $type => $items ) {
                        if ( ! empty( $items ) ) {
                            echo "- " . ucfirst( $type ) . " available\n";
                        }
                    }
                    echo "\n";
                }
            }
            
            echo "\n";
        }
        
        exit;
    }
    
    private function get_all_stories() {
        return get_posts( array(
            'post_type' => 'cool_timeline',
            'posts_per_page' => -1,
            'orderby' => 'meta_value',
            'meta_key' => 'ctl_story_date',
            'order' => 'ASC'
        ) );
    }
}

new CoolTimelineExport();