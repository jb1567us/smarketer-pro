<?php
class CoolTimelineSettings {
    
    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_settings_page' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_styles' ) );
    }
    
    public function add_settings_page() {
        add_menu_page(
            'Cool Timeline Settings',
            'Cool Timeline',
            'manage_options',
            'cool_timeline_settings',
            array( $this, 'render_settings_page' ),
            'dashicons-clock',
            30
        );
    }
    
    public function register_settings() {
        register_setting( 'cool_timeline_settings', 'ctl_settings' );
        
        add_settings_section(
            'ctl_general_section',
            'General Settings',
            array( $this, 'render_general_section' ),
            'cool_timeline_settings'
        );
        
        add_settings_section(
            'ctl_display_section',
            'Display Settings',
            array( $this, 'render_display_section' ),
            'cool_timeline_settings'
        );
        
        add_settings_section(
            'ctl_media_section',
            'Media Settings',
            array( $this, 'render_media_section' ),
            'cool_timeline_settings'
        );
        
        add_settings_field(
            'ctl_default_layout',
            'Default Timeline Layout',
            array( $this, 'render_layout_field' ),
            'cool_timeline_settings',
            'ctl_general_section'
        );
        
        add_settings_field(
            'ctl_posts_per_page',
            'Stories Per Page',
            array( $this, 'render_posts_per_page_field' ),
            'cool_timeline_settings',
            'ctl_general_section'
        );
        
        add_settings_field(
            'ctl_default_order',
            'Default Order',
            array( $this, 'render_order_field' ),
            'cool_timeline_settings',
            'ctl_general_section'
        );
        
        add_settings_field(
            'ctl_date_format',
            'Date Format',
            array( $this, 'render_date_format_field' ),
            'cool_timeline_settings',
            'ctl_display_section'
        );
        
        add_settings_field(
            'ctl_show_icons',
            'Show Timeline Icons',
            array( $this, 'render_show_icons_field' ),
            'cool_timeline_settings',
            'ctl_display_section'
        );
        
        add_settings_field(
            'ctl_animation',
            'Animation Effects',
            array( $this, 'render_animation_field' ),
            'cool_timeline_settings',
            'ctl_display_section'
        );
        
        add_settings_field(
            'ctl_image_size',
            'Default Image Size',
            array( $this, 'render_image_size_field' ),
            'cool_timeline_settings',
            'ctl_media_section'
        );
        
        add_settings_field(
            'ctl_lightbox',
            'Enable Lightbox',
            array( $this, 'render_lightbox_field' ),
            'cool_timeline_settings',
            'ctl_media_section'
        );
        
        add_settings_field(
            'ctl_lazy_loading',
            'Lazy Load Images',
            array( $this, 'render_lazy_loading_field' ),
            'cool_timeline_settings',
            'ctl_media_section'
        );
    }
    
    public function render_settings_page() {
        $settings = get_option( 'ctl_settings' );
        ?>
        <div class="wrap ctl-settings-wrap">
            <h1>Cool Timeline Settings</h1>
            
            <div class="ctl-settings-header">
                <div class="ctl-header-card">
                    <h3>Getting Started</h3>
                    <p>Create your first timeline story and add the shortcode to any page or post.</p>
                    <a href="<?php echo admin_url( 'post-new.php?post_type=cool_timeline' ); ?>" class="button button-primary">Add New Story</a>
                </div>
                
                <div class="ctl-header-card">
                    <h3>Shortcode Examples</h3>
                    <code>[cool-timeline]</code><br>
                    <code>[cool-timeline layout="horizontal" show_media="true"]</code><br>
                    <code>[cool-timeline posts_per_page="5" order="ASC"]</code>
                </div>
            </div>
            
            <form method="post" action="options.php">
                <?php
                settings_fields( 'cool_timeline_settings' );
                do_settings_sections( 'cool_timeline_settings' );
                submit_button( 'Save Settings' );
                ?>
            </form>
            
            <div class="ctl-settings-sidebar">
                <div class="ctl-sidebar-card">
                    <h3>Need Help?</h3>
                    <p>Check out our documentation or contact support.</p>
                    <a href="https://cooltimeline.com/docs" class="button" target="_blank">View Documentation</a>
                </div>
                
                <div class="ctl-sidebar-card">
                    <h3>Statistics</h3>
                    <p>Total Stories: <strong><?php echo $this->get_total_stories(); ?></strong></p>
                    <p>Stories with Media: <strong><?php echo $this->get_stories_with_media(); ?></strong></p>
                </div>
            </div>
        </div>
        <?php
    }
    
    public function render_general_section() {
        echo '<p>Configure the general behavior of your timelines.</p>';
    }
    
    public function render_display_section() {
        echo '<p>Customize how your timelines appear to visitors.</p>';
    }
    
    public function render_media_section() {
        echo '<p>Manage media and image settings for your timeline stories.</p>';
    }
    
    public function render_layout_field() {
        $settings = get_option( 'ctl_settings' );
        $value = isset( $settings['default_layout'] ) ? $settings['default_layout'] : 'vertical';
        ?>
        <select name="ctl_settings[default_layout]">
            <option value="vertical" <?php selected( $value, 'vertical' ); ?>>Vertical Timeline</option>
            <option value="horizontal" <?php selected( $value, 'horizontal' ); ?>>Horizontal Timeline</option>
            <option value="compact" <?php selected( $value, 'compact' ); ?>>Compact Timeline</option>
        </select>
        <p class="description">Choose the default layout for your timelines</p>
        <?php
    }
    
    public function render_posts_per_page_field() {
        $settings = get_option( 'ctl_settings' );
        $value = isset( $settings['posts_per_page'] ) ? $settings['posts_per_page'] : 10;
        ?>
        <input type="number" name="ctl_settings[posts_per_page]" value="<?php echo esc_attr( $value ); ?>" min="1" max="50" />
        <p class="description">Number of stories to show per page (1-50)</p>
        <?php
    }
    
    public function render_order_field() {
        $settings = get_option( 'ctl_settings' );
        $value = isset( $settings['default_order'] ) ? $settings['default_order'] : 'DESC';
        ?>
        <select name="ctl_settings[default_order]">
            <option value="DESC" <?php selected( $value, 'DESC' ); ?>>Newest First (DESC)</option>
            <option value="ASC" <?php selected( $value, 'ASC' ); ?>>Oldest First (ASC)</option>
        </select>
        <p class="description">Default order for timeline stories</p>
        <?php
    }
    
    public function render_date_format_field() {
        $settings = get_option( 'ctl_settings' );
        $value = isset( $settings['date_format'] ) ? $settings['date_format'] : 'F j, Y';
        ?>
        <input type="text" name="ctl_settings[date_format]" value="<?php echo esc_attr( $value ); ?>" class="regular-text" />
        <p class="description">PHP date format (e.g., F j, Y = January 1, 2024)</p>
        <?php
    }
    
    public function render_show_icons_field() {
        $settings = get_option( 'ctl_settings' );
        $value = isset( $settings['show_icons'] ) ? $settings['show_icons'] : 'yes';
        ?>
        <label>
            <input type="radio" name="ctl_settings[show_icons]" value="yes" <?php checked( $value, 'yes' ); ?> />
            Yes
        </label>
        <label>
            <input type="radio" name="ctl_settings[show_icons]" value="no" <?php checked( $value, 'no' ); ?> />
            No
        </label>
        <p class="description">Show icons/dots on the timeline</p>
        <?php
    }
    
    public function render_animation_field() {
        $settings = get_option( 'ctl_settings' );
        $value = isset( $settings['animation'] ) ? $settings['animation'] : 'fade';
        ?>
        <select name="ctl_settings[animation]">
            <option value="none" <?php selected( $value, 'none' ); ?>>No Animation</option>
            <option value="fade" <?php selected( $value, 'fade' ); ?>>Fade In</option>
            <option value="slide" <?php selected( $value, 'slide' ); ?>>Slide Up</option>
        </select>
        <p class="description">Animation effect for timeline items</p>
        <?php
    }
    
    public function render_image_size_field() {
        $settings = get_option( 'ctl_settings' );
        $value = isset( $settings['image_size'] ) ? $settings['image_size'] : 'medium';
        $sizes = get_intermediate_image_sizes();
        ?>
        <select name="ctl_settings[image_size]">
            <?php foreach ( $sizes as $size ) : ?>
                <option value="<?php echo esc_attr( $size ); ?>" <?php selected( $value, $size ); ?>>
                    <?php echo ucfirst( $size ); ?>
                </option>
            <?php endforeach; ?>
            <option value="full" <?php selected( $value, 'full' ); ?>>Full Size</option>
        </select>
        <p class="description">Default image size for timeline media</p>
        <?php
    }
    
    public function render_lightbox_field() {
        $settings = get_option( 'ctl_settings' );
        $value = isset( $settings['lightbox'] ) ? $settings['lightbox'] : 'yes';
        ?>
        <label>
            <input type="radio" name="ctl_settings[lightbox]" value="yes" <?php checked( $value, 'yes' ); ?> />
            Yes
        </label>
        <label>
            <input type="radio" name="ctl_settings[lightbox]" value="no" <?php checked( $value, 'no' ); ?> />
            No
        </label>
        <p class="description">Enable lightbox for gallery images</p>
        <?php
    }
    
    public function render_lazy_loading_field() {
        $settings = get_option( 'ctl_settings' );
        $value = isset( $settings['lazy_loading'] ) ? $settings['lazy_loading'] : 'yes';
        ?>
        <label>
            <input type="radio" name="ctl_settings[lazy_loading]" value="yes" <?php checked( $value, 'yes' ); ?> />
            Yes
        </label>
        <label>
            <input type="radio" name="ctl_settings[lazy_loading]" value="no" <?php checked( $value, 'no' ); ?> />
            No
        </label>
        <p class="description">Lazy load images for better performance</p>
        <?php
    }
    
    public function enqueue_admin_styles( $hook ) {
        if ( 'toplevel_page_cool_timeline_settings' !== $hook ) {
            return;
        }
        
        wp_add_inline_style( 'wp-admin', '
            .ctl-settings-wrap { max-width: 1200px; }
            .ctl-settings-header { 
                display: grid; 
                grid-template-columns: 1fr 1fr; 
                gap: 20px; 
                margin: 20px 0; 
            }
            .ctl-header-card, .ctl-sidebar-card { 
                background: white; 
                padding: 20px; 
                border: 1px solid #ccd0d4; 
                border-radius: 4px; 
            }
            .ctl-header-card h3, .ctl-sidebar-card h3 { 
                margin-top: 0; 
                color: #23282d; 
            }
            .ctl-settings-sidebar { 
                margin-top: 30px; 
                display: grid; 
                grid-template-columns: 1fr 1fr; 
                gap: 20px; 
            }
            .ctl-header-card code { 
                background: #f1f1f1; 
                padding: 2px 5px; 
                border-radius: 3px; 
                display: inline-block; 
                margin: 2px 0; 
            }
            .form-table th { width: 250px; }
        ' );
    }
    
    private function get_total_stories() {
        $count = wp_count_posts( 'cool_timeline' );
        return $count->publish;
    }
    
    private function get_stories_with_media() {
        $args = array(
            'post_type' => 'cool_timeline',
            'post_status' => 'publish',
            'meta_query' => array(
                'relation' => 'OR',
                array(
                    'key' => '_thumbnail_id',
                    'compare' => 'EXISTS'
                ),
                array(
                    'key' => 'ctl_gallery_images',
                    'compare' => 'EXISTS'
                ),
                array(
                    'key' => 'ctl_video_url',
                    'compare' => 'EXISTS'
                )
            ),
            'fields' => 'ids',
            'posts_per_page' => -1
        );
        
        $query = new WP_Query( $args );
        return $query->found_posts;
    }
}

new CoolTimelineSettings();