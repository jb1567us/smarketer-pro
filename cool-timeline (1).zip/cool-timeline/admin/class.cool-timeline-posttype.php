<?php
class CoolTimelinePostType {
    
    public function __construct() {
        add_action( 'init', array( $this, 'register_timeline_post_type' ) );
        add_action( 'init', array( $this, 'register_timeline_taxonomy' ) );
    }
    
    public function register_timeline_post_type() {
        $labels = array(
            'name' => __( 'Timeline Stories', 'cool-timeline' ),
            'singular_name' => __( 'Timeline Story', 'cool-timeline' ),
            'menu_name' => __( 'Timeline Stories', 'cool-timeline' ),
            'name_admin_bar' => __( 'Timeline Story', 'cool-timeline' ),
            'add_new' => __( 'Add New', 'cool-timeline' ),
            'add_new_item' => __( 'Add New Story', 'cool-timeline' ),
            'new_item' => __( 'New Story', 'cool-timeline' ),
            'edit_item' => __( 'Edit Story', 'cool-timeline' ),
            'view_item' => __( 'View Story', 'cool-timeline' ),
            'all_items' => __( 'All Stories', 'cool-timeline' ),
            'search_items' => __( 'Search Stories', 'cool-timeline' ),
            'parent_item_colon' => __( 'Parent Stories:', 'cool-timeline' ),
            'not_found' => __( 'No stories found.', 'cool-timeline' ),
            'not_found_in_trash' => __( 'No stories found in Trash.', 'cool-timeline' )
        );
        
        $args = array(
            'labels' => $labels,
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'query_var' => true,
            'rewrite' => array( 'slug' => 'timeline-story' ),
            'capability_type' => 'post',
            'has_archive' => false,
            'hierarchical' => false,
            'menu_position' => 30,
            'menu_icon' => 'dashicons-clock',
            'supports' => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
            'show_in_rest' => true,
        );
        
        register_post_type( 'cool_timeline', $args );
    }
    
    public function register_timeline_taxonomy() {
        $labels = array(
            'name' => __( 'Timeline Categories', 'cool-timeline' ),
            'singular_name' => __( 'Timeline Category', 'cool-timeline' ),
            'search_items' => __( 'Search Categories', 'cool-timeline' ),
            'all_items' => __( 'All Categories', 'cool-timeline' ),
            'parent_item' => __( 'Parent Category', 'cool-timeline' ),
            'parent_item_colon' => __( 'Parent Category:', 'cool-timeline' ),
            'edit_item' => __( 'Edit Category', 'cool-timeline' ),
            'update_item' => __( 'Update Category', 'cool-timeline' ),
            'add_new_item' => __( 'Add New Category', 'cool-timeline' ),
            'new_item_name' => __( 'New Category Name', 'cool-timeline' ),
            'menu_name' => __( 'Categories', 'cool-timeline' ),
        );
        
        $args = array(
            'hierarchical' => true,
            'labels' => $labels,
            'show_ui' => true,
            'show_admin_column' => true,
            'query_var' => true,
            'rewrite' => array( 'slug' => 'timeline-category' ),
            'show_in_rest' => true,
        );
        
        register_taxonomy( 'timeline_category', array( 'cool_timeline' ), $args );
    }
}

new CoolTimelinePostType();