<?php
/*
  Plugin Name: Cool Timeline Pro
  Plugin URI: https://cooltimeline.com
  Description: Timeline plugin with full media support - images, videos, files, and galleries. Perfect for historical documentation and book projects.
  Version: 3.4.0
  Author: Cool Plugins
  License: GPLv2 or later
  Text Domain: cool-timeline
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'CTL_V' ) ) {
	define( 'CTL_V', '3.4.0' );
}

define( 'CTL_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'CTL_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

// Include post type registration FIRST
require_once CTL_PLUGIN_DIR . 'admin/class.cool-timeline-posttype.php';

if ( ! class_exists( 'CoolTimelinePro' ) ) {
	final class CoolTimelinePro {

		private static $instance;
		private $cache_group = 'cool_timeline';
		private $cache_time = 3600;

		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		public static function registers() {
			$thisIns = self::$instance;
			
			register_activation_hook( __FILE__, array( $thisIns, 'ctl_activate' ) );
			register_deactivation_hook( __FILE__, array( $thisIns, 'ctl_deactivate' ) );

			add_action( 'init', array( $thisIns, 'ctl_init' ) );
			add_action( 'wp_enqueue_scripts', array( $thisIns, 'ctl_conditional_assets' ) );
			
			if ( is_admin() ) {
				$pluginpath = plugin_basename( __FILE__ );
				add_filter( "plugin_action_links_$pluginpath", array( $thisIns, 'ctl_settings_link' ) );
				add_action( 'save_post', array( $thisIns, 'ctl_save_story_meta' ), 10, 3 );
			}

			if ( function_exists( 'register_block_type' ) ) {
				add_action( 'init', array( $thisIns, 'ctl_register_blocks' ) );
			}

			// Add collaboration features
			add_action( 'init', array( $thisIns, 'ctl_collaboration_features' ) );
		}

		public function ctl_collaboration_features() {
		    // Add co-author support
		    add_post_type_support( 'cool_timeline', 'author' );
		    
		    // Add revision support for tracking changes
		    add_post_type_support( 'cool_timeline', 'revisions' );
		    
		    // Add comments for discussion
		    add_post_type_support( 'cool_timeline', 'comments' );
		}

		public function ctl_init() {
			$this->ctl_include_files();
			$this->ctl_load_plugin_textdomain();
			$this->ctl_flush_rules();
		}

		public function ctl_include_files() {
			require_once CTL_PLUGIN_DIR . 'includes/shortcodes/class-ctl-helpers.php';
			require_once CTL_PLUGIN_DIR . 'includes/shortcodes/class-ctl-shortcode.php';
			
			if ( is_admin() ) {
				require_once CTL_PLUGIN_DIR . 'admin/ctl-admin-settings.php';
				require_once CTL_PLUGIN_DIR . 'admin/ctl-meta-fields.php';
				require_once CTL_PLUGIN_DIR . 'admin/ctl-export.php';
			}
		}

		public function ctl_save_story_meta( $post_id, $post, $update ) {
			if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
				return;
			}
			
			if ( 'cool_timeline' !== $post->post_type ) {
				return;
			}
			
			if ( ! isset( $_POST['ctl_media_nonce'] ) || ! wp_verify_nonce( $_POST['ctl_media_nonce'], 'ctl_save_media' ) ) {
				return;
			}

			$this->ctl_clear_cache();

			// Save story date
			if ( isset( $_POST['ctl_story_date'] ) ) {
				$story_date = sanitize_text_field( $_POST['ctl_story_date'] );
				$story_timestamp = $this->ctl_generate_timestamp( $story_date );
				update_post_meta( $post_id, 'ctl_story_timestamp', $story_timestamp );
				update_post_meta( $post_id, 'ctl_story_date', $story_date );
			}

			// Save research metadata
			$research_fields = array(
				'ctl_story_location',
				'ctl_story_source', 
				'ctl_story_importance',
				'ctl_research_status'
			);
			
			foreach ( $research_fields as $field ) {
				if ( isset( $_POST[$field] ) ) {
					update_post_meta( $post_id, $field, sanitize_text_field( $_POST[$field] ) );
				}
			}

			$this->ctl_save_media_fields( $post_id );
		}

		private function ctl_save_media_fields( $post_id ) {
			// Gallery images
			if ( isset( $_POST['ctl_gallery_images'] ) ) {
				$gallery_images = array_filter( array_map( 'intval', explode( ',', $_POST['ctl_gallery_images'] ) ) );
				update_post_meta( $post_id, 'ctl_gallery_images', $gallery_images );
			} else {
				delete_post_meta( $post_id, 'ctl_gallery_images' );
			}

			// Video URL
			if ( isset( $_POST['ctl_video_url'] ) ) {
				$video_url = esc_url_raw( $_POST['ctl_video_url'] );
				update_post_meta( $post_id, 'ctl_video_url', $video_url );
			} else {
				delete_post_meta( $post_id, 'ctl_video_url' );
			}

			// File attachments
			if ( isset( $_POST['ctl_file_attachments'] ) ) {
				$file_attachments = array_filter( array_map( 'intval', explode( ',', $_POST['ctl_file_attachments'] ) ) );
				update_post_meta( $post_id, 'ctl_file_attachments', $file_attachments );
			} else {
				delete_post_meta( $post_id, 'ctl_file_attachments' );
			}
		}

		public function ctl_get_story_media( $post_id ) {
			$cache_key = 'story_media_' . $post_id;
			$media = wp_cache_get( $cache_key, $this->cache_group );
			
			if ( false !== $media ) {
				return $media;
			}
			
			$media = array();
			
			// Featured image
			if ( has_post_thumbnail( $post_id ) ) {
				$thumb_id = get_post_thumbnail_id( $post_id );
				$media['featured_image'] = array(
					'id'  => $thumb_id,
					'url' => wp_get_attachment_image_url( $thumb_id, 'medium' ),
					'alt' => get_post_meta( $thumb_id, '_wp_attachment_image_alt', true ),
					'full_url' => wp_get_attachment_url( $thumb_id )
				);
			}
			
			// Gallery images
			$gallery_images = get_post_meta( $post_id, 'ctl_gallery_images', true );
			if ( ! empty( $gallery_images ) && is_array( $gallery_images ) ) {
				$media['gallery'] = array();
				foreach ( array_slice( $gallery_images, 0, 10 ) as $image_id ) {
					$image_url = wp_get_attachment_image_url( $image_id, 'medium' );
					if ( $image_url ) {
						$media['gallery'][] = array(
							'id'  => $image_id,
							'url' => $image_url,
							'alt' => get_post_meta( $image_id, '_wp_attachment_image_alt', true ),
							'full_url' => wp_get_attachment_url( $image_id )
						);
					}
				}
			}
			
			// Video - FIXED EMBED GENERATION
			$video_url = get_post_meta( $post_id, 'ctl_video_url', true );
			if ( ! empty( $video_url ) ) {
				$embed_code = $this->ctl_generate_video_embed( $video_url );
				$media['video'] = array(
					'url' => $video_url,
					'embed' => $embed_code
				);
			}
			
			// File attachments
			$file_attachments = get_post_meta( $post_id, 'ctl_file_attachments', true );
			if ( ! empty( $file_attachments ) && is_array( $file_attachments ) ) {
				$media['files'] = array();
				foreach ( $file_attachments as $file_id ) {
					$file_url = wp_get_attachment_url( $file_id );
					if ( $file_url ) {
						$file_size = '';
						$file_path = get_attached_file( $file_id );
						if ( file_exists( $file_path ) ) {
							$file_size = size_format( filesize( $file_path ) );
						}
						
						$media['files'][] = array(
							'id'   => $file_id,
							'url'  => $file_url,
							'name' => get_the_title( $file_id ),
							'type' => get_post_mime_type( $file_id ),
							'size' => $file_size
						);
					}
				}
			}
			
			wp_cache_set( $cache_key, $media, $this->cache_group, $this->cache_time );
			return $media;
		}

		// NEW METHOD: Generate video embed code
		private function ctl_generate_video_embed( $video_url ) {
			// Try WordPress oEmbed first
			$embed_code = wp_oembed_get( $video_url, array( 'width' => 800 ) );
			
			if ( $embed_code ) {
				return $embed_code;
			}
			
			// If oEmbed fails, handle specific video types
			$parsed_url = parse_url( $video_url );
			$host = strtolower( $parsed_url['host'] ?? '' );
			
			// YouTube Shorts and various YouTube URLs
			if ( strpos( $host, 'youtube.com' ) !== false || strpos( $host, 'youtu.be' ) !== false ) {
				return $this->ctl_generate_youtube_embed( $video_url );
			}
			
			// Vimeo
			if ( strpos( $host, 'vimeo.com' ) !== false ) {
				return $this->ctl_generate_vimeo_embed( $video_url );
			}
			
			// Self-hosted videos
			$file_ext = pathinfo( $video_url, PATHINFO_EXTENSION );
			if ( in_array( strtolower( $file_ext ), array( 'mp4', 'webm', 'ogg', 'mov' ) ) ) {
				return $this->ctl_generate_self_hosted_embed( $video_url );
			}
			
			// Fallback - simple link
			return '<div class="ctl-video-fallback">
				<p>Unable to embed video. <a href="' . esc_url( $video_url ) . '" target="_blank" class="button ctl-video-link">Watch Video</a></p>
			</div>';
		}

		// YouTube embed generator
		private function ctl_generate_youtube_embed( $url ) {
			$video_id = '';
			
			// Regular YouTube URL: https://www.youtube.com/watch?v=VIDEO_ID
			if ( preg_match( '/youtube\.com.*[?&]v=([^&]+)/', $url, $matches ) ) {
				$video_id = $matches[1];
			}
			// YouTube Shorts: https://www.youtube.com/shorts/VIDEO_ID
			elseif ( preg_match( '/youtube\.com\/shorts\/([^&]+)/', $url, $matches ) ) {
				$video_id = $matches[1];
			}
			// youtu.be URL: https://youtu.be/VIDEO_ID
			elseif ( preg_match( '/youtu\.be\/([^&]+)/', $url, $matches ) ) {
				$video_id = $matches[1];
			}
			
			if ( $video_id ) {
				return '<div class="ctl-video-embed">
					<iframe width="100%" height="400" 
							src="https://www.youtube.com/embed/' . esc_attr( $video_id ) . '?rel=0" 
							frameborder="0" 
							allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
							allowfullscreen>
					</iframe>
				</div>';
			}
			
			return false;
		}

		// Vimeo embed generator
		private function ctl_generate_vimeo_embed( $url ) {
			// Extract video ID from Vimeo URL
			if ( preg_match( '/vimeo\.com\/(\d+)/', $url, $matches ) ) {
				$video_id = $matches[1];
				return '<div class="ctl-video-embed">
					<iframe src="https://player.vimeo.com/video/' . esc_attr( $video_id ) . '" 
							width="100%" height="400" 
							frameborder="0" 
							allow="autoplay; fullscreen; picture-in-picture" 
							allowfullscreen>
					</iframe>
				</div>';
			}
			
			return false;
		}

		// Self-hosted video embed generator
		private function ctl_generate_self_hosted_embed( $url ) {
			$file_ext = pathinfo( $url, PATHINFO_EXTENSION );
			$mime_types = array(
				'mp4' => 'video/mp4',
				'webm' => 'video/webm',
				'ogg' => 'video/ogg',
				'mov' => 'video/quicktime'
			);
			
			$mime_type = $mime_types[ strtolower( $file_ext ) ] ?? 'video/mp4';
			
			return '<div class="ctl-self-hosted-video">
				<video controls width="100%" style="max-height: 400px;">
					<source src="' . esc_url( $url ) . '" type="' . esc_attr( $mime_type ) . '">
					Your browser does not support the video tag.
					<a href="' . esc_url( $url ) . '" download>Download Video</a>
				</video>
			</div>';
		}

		public function ctl_conditional_assets() {
			global $post;
			
			if ( is_admin() || ( is_a( $post, 'WP_Post' ) && 
				( has_shortcode( $post->post_content, 'cool-timeline' ) || 
				  has_block( 'cool-timeline/timeline', $post ) ) ) ) {
				
				$this->ctl_load_assets();
			}
		}

		private function ctl_load_assets() {
			wp_enqueue_style( 
				'cool-timeline', 
				CTL_PLUGIN_URL . 'assets/css/timeline.min.css', 
				array(), 
				CTL_V 
			);
			
			wp_enqueue_script( 
				'cool-timeline-frontend', 
				CTL_PLUGIN_URL . 'assets/js/timeline-frontend.js', 
				array( 'jquery' ), 
				CTL_V, 
				true 
			);
		}

		public function ctl_register_blocks() {
			register_block_type( 'cool-timeline/timeline', array(
				'render_callback' => array( $this, 'ctl_render_timeline_block' ),
				'attributes'      => array(
					'layout' => array(
						'type'    => 'string',
						'default' => 'vertical',
					),
					'showMedia' => array(
						'type'    => 'boolean',
						'default' => true,
					),
					'postsPerPage' => array(
						'type'    => 'number',
						'default' => 10,
					),
					'style' => array(
						'type'    => 'string',
						'default' => 'default',
					),
				),
			) );
		}

		public function ctl_render_timeline_block( $attributes ) {
			$cache_key = 'timeline_block_' . md5( serialize( $attributes ) );
			$output = wp_cache_get( $cache_key, $this->cache_group );
			
			if ( false === $output ) {
				$output = $this->ctl_generate_timeline_output( $attributes );
				wp_cache_set( $cache_key, $output, $this->cache_group, $this->cache_time );
			}
			
			return $output;
		}

		private function ctl_generate_timeline_output( $args ) {
			$defaults = array(
				'layout'       => 'vertical',
				'show_media'   => true,
				'posts_per_page' => 10,
				'order'        => 'DESC',
				'style'        => 'default',
			);
			
			$args = wp_parse_args( $args, $defaults );
			
			$cache_key = 'timeline_posts_' . md5( serialize( $args ) );
			$timeline_posts = wp_cache_get( $cache_key, $this->cache_group );
			
			if ( false === $timeline_posts ) {
				$timeline_posts = $this->ctl_get_timeline_posts( $args );
				wp_cache_set( $cache_key, $timeline_posts, $this->cache_group, $this->cache_time / 2 );
			}
			
			ob_start();
			$this->ctl_display_timeline( $timeline_posts, $args );
			return ob_get_clean();
		}

		private function ctl_get_timeline_posts( $args ) {
			$query_args = array(
				'post_type'      => 'cool_timeline',
				'posts_per_page' => intval( $args['posts_per_page'] ),
				'order'          => $args['order'],
				'orderby'        => 'meta_value_num',
				'meta_key'       => 'ctl_story_timestamp',
				'meta_query'     => array(
					array(
						'key'     => 'ctl_story_timestamp',
						'compare' => 'EXISTS',
					),
				),
				'no_found_rows'  => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			);
			
			return get_posts( $query_args );
		}

		private function ctl_display_timeline( $posts, $args ) {
			if ( empty( $posts ) ) {
				echo '<p>No timeline stories found.</p>';
				return;
			}
			
			$layout_class = 'ctl-layout-' . sanitize_html_class( $args['layout'] );
			$style_class = 'default' === $args['style'] ? '' : 'ctl-condensed';
			?>
			<div class="cool-timeline <?php echo $layout_class . ' ' . $style_class; ?>">
				<?php foreach ( $posts as $post ) : 
					setup_postdata( $post );
					$this->ctl_display_timeline_item( $post, $args );
				endforeach; 
				wp_reset_postdata();
				?>
			</div>
			<?php
		}

		private function ctl_display_timeline_item( $post, $args ) {
			$story_date = get_post_meta( $post->ID, 'ctl_story_date', true );
			$location = get_post_meta( $post->ID, 'ctl_story_location', true );
			$source = get_post_meta( $post->ID, 'ctl_story_source', true );
			$importance = get_post_meta( $post->ID, 'ctl_story_importance', true );
			$research_status = get_post_meta( $post->ID, 'ctl_research_status', true );
			$media = $args['show_media'] ? $this->ctl_get_story_media( $post->ID ) : array();
			
			// Importance stars
			$importance_stars = array(
				'minor' => '⭐',
				'significant' => '⭐⭐', 
				'major' => '⭐⭐⭐',
				'turning_point' => '⭐⭐⭐⭐'
			);
			
			// Check what media types are available
			$has_featured = ! empty( $media['featured_image'] );
			$has_gallery = ! empty( $media['gallery'] );
			$has_video = ! empty( $media['video'] );
			$has_files = ! empty( $media['files'] );
			$has_any_media = $has_featured || $has_gallery || $has_video || $has_files;
			
			// Get author info
			$author_name = get_the_author_meta( 'display_name', $post->post_author );
			$last_edited = get_the_modified_date( 'F j, Y', $post );
			
			// Check if we're in condensed mode
			$is_condensed = isset( $args['style'] ) && 'condensed' === $args['style'];
			?>
			<div class="ctl-item" data-date="<?php echo esc_attr( $story_date ); ?>">
				<div class="ctl-item-content">
					<?php if ( $is_condensed ) : ?>
						<!-- Condensed Header -->
						<div class="ctl-header">
							<span class="ctl-date"><?php echo esc_html( $story_date ); ?></span>
							<span class="ctl-title">
								<?php echo esc_html( get_the_title( $post ) ); ?>
								<?php if ( $importance ) : ?>
									<span class="ctl-importance-indicator" title="Historical Importance">
										<?php echo $importance_stars[$importance] ?? ''; ?>
									</span>
								<?php endif; ?>
								<?php if ( $research_status ) : ?>
									<span class="ctl-research-badge ctl-badge-<?php echo esc_attr( $research_status ); ?>">
										<?php echo ucfirst( str_replace( '_', ' ', $research_status ) ); ?>
									</span>
								<?php endif; ?>
							</span>
							
							<div class="ctl-meta-items">
								<?php if ( $location ) : ?>
									<span class="ctl-meta-item" title="Location">
										📍<?php echo esc_html( $location ); ?>
									</span>
								<?php endif; ?>
								
								<span class="ctl-meta-item" title="Author">
									👤<?php echo esc_html( $author_name ); ?>
								</span>
								
								<span class="ctl-meta-item" title="Last Edited">
									📝<?php echo esc_html( $last_edited ); ?>
								</span>
							</div>
						</div>
						
						<!-- Content -->
						<div class="ctl-content">
							<?php 
							$content = get_the_content( null, false, $post );
							if ( ! empty( $content ) ) {
								echo wp_kses_post( wp_trim_words( $content, 30, '...' ) );
							}
							?>
						</div>
						
						<?php if ( $source ) : ?>
							<div class="ctl-source-info">
								<strong>Sources:</strong> <?php echo esc_html( wp_trim_words( $source, 10, '...' ) ); ?>
							</div>
						<?php endif; ?>
						
					<?php else : ?>
						<!-- Default Layout -->
						<div class="ctl-date"><?php echo esc_html( $story_date ); ?></div>
						
						<h3 class="ctl-title">
							<?php echo esc_html( get_the_title( $post ) ); ?>
							<?php if ( $importance ) : ?>
								<span class="ctl-importance-indicator" title="Historical Importance">
									<?php echo $importance_stars[$importance] ?? ''; ?>
								</span>
							<?php endif; ?>
							<?php if ( $research_status ) : ?>
								<span class="ctl-research-badge ctl-badge-<?php echo esc_attr( $research_status ); ?>">
									<?php echo ucfirst( str_replace( '_', ' ', $research_status ) ); ?>
								</span>
							<?php endif; ?>
						</h3>
						
						<!-- Research Metadata -->
						<div class="ctl-story-meta">
							<?php if ( $location ) : ?>
								<div class="ctl-meta-item">
									<span>📍</span>
									<span><?php echo esc_html( $location ); ?></span>
								</div>
							<?php endif; ?>
							
							<div class="ctl-meta-item">
								<span>👤</span>
								<span><?php echo esc_html( $author_name ); ?></span>
							</div>
							
							<div class="ctl-meta-item">
								<span>📝</span>
								<span>Last edited: <?php echo esc_html( $last_edited ); ?></span>
							</div>
						</div>
						
						<?php if ( $source ) : ?>
							<div class="ctl-source-info">
								<strong>Sources:</strong> <?php echo esc_html( $source ); ?>
							</div>
						<?php endif; ?>
						
						<div class="ctl-content">
							<?php echo wp_kses_post( get_the_content( null, false, $post ) ); ?>
						</div>
					<?php endif; ?>
					
					<?php if ( $has_any_media ) : ?>
						<!-- Media Icons Bar -->
						<div class="ctl-media-icons">
							<?php if ( $has_featured ) : ?>
								<div class="ctl-media-icon has-media" data-type="featured" title="Featured Image">
									🖼️
								</div>
							<?php endif; ?>
							
							<?php if ( $has_gallery ) : ?>
								<div class="ctl-media-icon has-media" data-type="gallery" title="Image Gallery (<?php echo count( $media['gallery'] ); ?> images)">
									🎞️
								</div>
							<?php endif; ?>
							
							<?php if ( $has_video ) : ?>
								<div class="ctl-media-icon has-media" data-type="video" title="Video">
									▶️
								</div>
							<?php endif; ?>
							
							<?php if ( $has_files ) : ?>
								<div class="ctl-media-icon has-media" data-type="files" title="File Attachments (<?php echo count( $media['files'] ); ?> files)">
									📎
								</div>
							<?php endif; ?>
						</div>
						
						<!-- Media Containers -->
						<?php if ( $has_featured ) : ?>
							<div class="ctl-media-container" data-type="featured">
								<div class="ctl-featured-media">
									<img src="<?php echo esc_url( $media['featured_image']['url'] ); ?>" 
										 alt="<?php echo esc_attr( $media['featured_image']['alt'] ); ?>" 
										 class="ctl-featured-image">
								</div>
								<button class="ctl-close-media">Close</button>
							</div>
						<?php endif; ?>
						
						<?php if ( $has_gallery ) : ?>
							<div class="ctl-media-container" data-type="gallery">
								<div class="ctl-gallery-grid">
									<?php foreach ( $media['gallery'] as $image ) : ?>
										<img src="<?php echo esc_url( $image['url'] ); ?>" 
											 alt="<?php echo esc_attr( $image['alt'] ); ?>" 
											 data-full="<?php echo esc_url( $image['full_url'] ); ?>"
											 class="ctl-gallery-image">
									<?php endforeach; ?>
								</div>
								<button class="ctl-close-media">Close Gallery</button>
							</div>
						<?php endif; ?>
						
						<?php if ( $has_video ) : ?>
							<div class="ctl-media-container" data-type="video">
								<div class="ctl-video-container">
									<?php echo $media['video']['embed']; ?>
								</div>
								<button class="ctl-close-media">Close Video</button>
							</div>
						<?php endif; ?>
						
						<?php if ( $has_files ) : ?>
							<div class="ctl-media-container" data-type="files">
								<ul class="ctl-file-list">
									<?php foreach ( $media['files'] as $file ) : ?>
										<li class="ctl-file-item">
											<a href="<?php echo esc_url( $file['url'] ); ?>" 
											   download 
											   class="ctl-file-link">
												<span class="ctl-file-icon">📄</span>
												<span class="ctl-file-name"><?php echo esc_html( $file['name'] ); ?></span>
												<?php if ( ! empty( $file['size'] ) ) : ?>
													<span class="ctl-file-size">(<?php echo esc_html( $file['size'] ); ?>)</span>
												<?php endif; ?>
											</a>
										</li>
									<?php endforeach; ?>
								</ul>
								<button class="ctl-close-media">Close Files</button>
							</div>
						<?php endif; ?>
					<?php endif; ?>
				</div>
			</div>
			
			<!-- Lightbox HTML -->
			<div id="ctl-lightbox" class="ctl-lightbox">
				<button class="ctl-lightbox-close">×</button>
				<img id="ctl-lightbox-image" src="" alt="">
			</div>
			<?php
		}

		public function ctl_load_plugin_textdomain() {
			load_plugin_textdomain( 'cool-timeline', false, basename( dirname( __FILE__ ) ) . '/languages/' );
		}

		public function ctl_flush_rules() {
			if ( get_option( 'ctl_flush_rewrite_rules_flag' ) ) {
				flush_rewrite_rules();
				delete_option( 'ctl_flush_rewrite_rules_flag' );
			}
		}

		public function ctl_settings_link( $links ) {
			array_unshift( $links, '<a href="admin.php?page=cool_timeline_settings">Settings</a>' );
			array_push( $links, '<a href="admin.php?page=ctl_export" style="color: #007cba; font-weight: bold;">Book Export</a>' );
			return $links;
		}

		public function ctl_activate() {
			update_option( 'ctl_flush_rewrite_rules_flag', true );
		}

		public function ctl_deactivate() {
			$this->ctl_clear_cache();
		}

		private function ctl_clear_cache() {
			wp_cache_delete( 'timeline_data', $this->cache_group );
		}

		private function ctl_generate_timestamp( $date_string ) {
			return strtotime( $date_string );
		}
	}
}

$cool_timeline = CoolTimelinePro::get_instance();
$cool_timeline->registers();