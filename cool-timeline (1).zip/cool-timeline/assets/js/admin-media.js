jQuery(document).ready(function($) {
    // Gallery Images
    var ctl_gallery_frame;
    
    $('.ctl-add-gallery-images').on('click', function(e) {
        e.preventDefault();
        
        if (ctl_gallery_frame) {
            ctl_gallery_frame.open();
            return;
        }
        
        ctl_gallery_frame = wp.media({
            title: 'Select Gallery Images',
            button: {
                text: 'Add to Gallery'
            },
            multiple: true
        });
        
        ctl_gallery_frame.on('select', function() {
            var attachment_ids = $('#ctl_gallery_images').val();
            var attachment_array = attachment_ids ? attachment_ids.split(',') : [];
            var attachments = ctl_gallery_frame.state().get('selection').toJSON();
            
            attachments.forEach(function(attachment) {
                if ($.inArray(attachment.id.toString(), attachment_array) === -1) {
                    attachment_array.push(attachment.id);
                }
            });
            
            $('#ctl_gallery_images').val(attachment_array.join(','));
            location.reload(); // Refresh to show new images
        });
        
        ctl_gallery_frame.open();
    });
    
    // Remove gallery image
    $(document).on('click', '.ctl-remove-image', function() {
        var thumb = $(this).closest('.ctl-gallery-thumb');
        var attachment_id = thumb.data('id');
        var attachment_ids = $('#ctl_gallery_images').val();
        var attachment_array = attachment_ids.split(',');
        
        var index = attachment_array.indexOf(attachment_id.toString());
        if (index !== -1) {
            attachment_array.splice(index, 1);
        }
        
        $('#ctl_gallery_images').val(attachment_array.join(','));
        thumb.remove();
    });
    
    // File Attachments
    var ctl_file_frame;
    
    $('.ctl-add-files').on('click', function(e) {
        e.preventDefault();
        
        if (ctl_file_frame) {
            ctl_file_frame.open();
            return;
        }
        
        ctl_file_frame = wp.media({
            title: 'Select Files to Attach',
            button: {
                text: 'Attach Files'
            },
            multiple: true
        });
        
        ctl_file_frame.on('select', function() {
            var attachment_ids = $('#ctl_file_attachments').val();
            var attachment_array = attachment_ids ? attachment_ids.split(',') : [];
            var attachments = ctl_file_frame.state().get('selection').toJSON();
            
            attachments.forEach(function(attachment) {
                if ($.inArray(attachment.id.toString(), attachment_array) === -1) {
                    attachment_array.push(attachment.id);
                }
            });
            
            $('#ctl_file_attachments').val(attachment_array.join(','));
            location.reload(); // Refresh to show new files
        });
        
        ctl_file_frame.open();
    });
    
    // Remove file attachment
    $(document).on('click', '.ctl-remove-file', function() {
        var file_item = $(this).closest('.ctl-file-item');
        var attachment_id = file_item.data('id');
        var attachment_ids = $('#ctl_file_attachments').val();
        var attachment_array = attachment_ids.split(',');
        
        var index = attachment_array.indexOf(attachment_id.toString());
        if (index !== -1) {
            attachment_array.splice(index, 1);
        }
        
        $('#ctl_file_attachments').val(attachment_array.join(','));
        file_item.remove();
    });
});