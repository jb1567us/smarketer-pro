jQuery(document).ready(function($) {
    // Media icon click handlers
    $('.ctl-media-icon').on('click', function() {
        var mediaType = $(this).data('type');
        var container = $(this).closest('.ctl-item-content').find('.ctl-media-container[data-type="' + mediaType + '"]');
        
        // Close all other media containers
        $('.ctl-media-container').removeClass('active');
        
        // Toggle current container
        container.toggleClass('active');
        
        // Scroll to media if it's opened
        if (container.hasClass('active')) {
            $('html, body').animate({
                scrollTop: container.offset().top - 100
            }, 500);
        }
    });
    
    // Close media containers
    $('.ctl-close-media').on('click', function() {
        $(this).closest('.ctl-media-container').removeClass('active');
    });
    
    // Gallery lightbox
    $('.ctl-gallery-image').on('click', function() {
        var src = $(this).data('full') || $(this).attr('src');
        $('#ctl-lightbox-image').attr('src', src);
        $('#ctl-lightbox').addClass('active');
    });
    
    // Close lightbox
    $('.ctl-lightbox-close, #ctl-lightbox').on('click', function(e) {
        if (e.target === this || $(e.target).hasClass('ctl-lightbox-close')) {
            $('#ctl-lightbox').removeClass('active');
        }
    });
    
    // Close with ESC key
    $(document).on('keyup', function(e) {
        if (e.keyCode === 27) {
            $('#ctl-lightbox').removeClass('active');
            $('.ctl-media-container').removeClass('active');
        }
    });
});