<?php
/**
 * Hatch Band functions and definitions
 */

if (!defined('ABSPATH')) {
    exit;
}

function hatch_band_setup() {
    // Make theme available for translation
    load_theme_textdomain('hatch-band', get_template_directory() . '/languages');
    
    // Add default posts and comments RSS feed links to head
    add_theme_support('automatic-feed-links');
    
    // Let WordPress manage the document title
    add_theme_support('title-tag');
    
    // Enable support for Post Thumbnails
    add_theme_support('post-thumbnails');
    
    // HTML5 support
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'hatch-band'),
    ));
}
add_action('after_setup_theme', 'hatch_band_setup');

function hatch_band_scripts() {
    // Enqueue styles
    wp_enqueue_style('hatch-band-style', get_stylesheet_uri());
    
    // Enqueue Google Fonts
    wp_enqueue_style('hatch-band-google-fonts', 'https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;1,400&family=Lato:ital,wght@0,300;0,400;1,300;1,400&display=swap', array(), null);
    
    // Enqueue scripts
    wp_enqueue_script('hatch-band-script', get_template_directory_uri() . '/js/script.js', array(), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'hatch_band_scripts');

// Simple menu fallback
function hatch_band_fallback_menu() {
    return '<ul><li><a href="' . home_url() . '">' . __('Home', 'hatch-band') . '</a></li><li><a href="' . home_url('/about') . '">' . __('About', 'hatch-band') . '</a></li><li><a href="' . home_url('/contact') . '">' . __('Contact', 'hatch-band') . '</a></li></ul>';
}

// Add body class for better styling
function hatch_band_body_classes($classes) {
    if (is_home() || is_front_page()) {
        $classes[] = 'home-page';
    }
    return $classes;
}
add_filter('body_class', 'hatch_band_body_classes');
?>