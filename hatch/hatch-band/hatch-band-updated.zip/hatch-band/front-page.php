<?php
/**
 * The homepage template for Hatch Band
 */
get_header();
?>

<div class="homepage-container">
    <div class="release-list">
        <?php
        // Hardcoded releases data
        $releases = array(
            array(
                'title' => 'Hatch House',
                'image' => get_template_directory_uri() . '/images/hatch_house.jpg',
                'bandcamp_url' => 'https://destinyrecords.bandcamp.com/album/hatch-house'
            ),
            array(
                'title' => 'Modernity',
                'image' => get_template_directory_uri() . '/images/modernity.jpg',
                'bandcamp_url' => 'https://destinyrecords.bandcamp.com/album/modernity'
            ),
            array(
                'title' => 'Symphony',
                'image' => get_template_directory_uri() . '/images/symphony.jpg',
                'bandcamp_url' => 'https://destinyrecords.bandcamp.com/album/symphony'
            ),
            array(
                'title' => 'Trees',
                'image' => get_template_directory_uri() . '/images/trees.jpg',
                'bandcamp_url' => 'https://destinyrecords.bandcamp.com/album/trees'
            )
        );
        
        foreach ($releases as $release) :
        ?>
            <div class="release-item">
                <a href="<?php echo esc_url($release['bandcamp_url']); ?>" target="_blank" class="release-link">
                    <div class="release-image-container">
                        <img src="<?php echo esc_url($release['image']); ?>" alt="<?php echo esc_attr($release['title']); ?>" class="release-image">
                    </div>
                    <div class="release-info">
                        <h2 class="release-title"><?php echo esc_html($release['title']); ?></h2>
                    </div>
                </a>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php get_footer(); ?>