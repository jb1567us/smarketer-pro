<?php
/**
 * The footer for Hatch Band theme
 */
?>
</main>

<footer class="site-footer">
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> Hatch Band. <?php _e('Theme by', 'hatch-band'); ?> <a href="https://baronbydesign.com" target="_blank">Baron By Design</a>.</p>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>