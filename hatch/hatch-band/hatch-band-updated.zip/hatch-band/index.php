<?php
/**
 * Default index template for Hatch Band theme
 */
get_header(); ?>

<div class="container">
    <div class="page-content">
        <h1><?php _e('Welcome to Hatch Band Theme', 'hatch-band'); ?></h1>
        <p><?php _e('This is the default index.php template. Replace this with your own templates.', 'hatch-band'); ?></p>
    </div>
</div>

<?php get_footer(); ?>
