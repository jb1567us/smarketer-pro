
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>January 22–31, 2026 • Weekly Destiny View</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
    :root {
      --bg: #0b0d10;
      --bg-alt: #151821;
      --text: #f5f7fb;
      --muted: #a3a8c3;
      --accent: #e2b857;
      --accent-soft: rgba(226, 184, 87, 0.12);
      --border: #292d3b;
      --card-bg: #151821;
      --shadow: 0 18px 35px rgba(0, 0, 0, 0.5);
      --font-main: system-ui, -apple-system, BlinkMacSystemFont, "SF Pro Text",
        "Segoe UI", sans-serif;
      --font-display: "Georgia", "Times New Roman", serif;
    }

    body {
      margin: 0;
      font-family: var(--font-main);
      background: radial-gradient(circle at top, #2a213b 0, #050308 60%);
      color: var(--text);
      -webkit-font-smoothing: antialiased;
    }

    .page {
      max-width: 1100px;
      margin: 0 auto;
      padding: 24px 16px 48px;
    }

    a {
      color: var(--accent);
      text-decoration: none;
    }

    a:hover {
      text-decoration: underline;
    }

    header {
      margin-bottom: 18px;
    }

    .back-link {
      font-size: 0.8rem;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: var(--muted);
      display: inline-flex;
      align-items: center;
      gap: 6px;
      margin-bottom: 10px;
    }

    h1 {
      margin: 0;
      font-family: var(--font-display);
      font-size: 1.7rem;
      letter-spacing: 0.06em;
      text-transform: uppercase;
    }

    .subtitle {
      font-size: 0.95rem;
      color: var(--muted);
      margin-top: 4px;
    }

    .week-meta {
      margin-top: 10px;
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    }

    .pill {
      padding: 4px 10px;
      border-radius: 999px;
      border: 1px solid var(--border);
      font-size: 0.75rem;
      text-transform: uppercase;
      letter-spacing: 0.07em;
      color: var(--muted);
      background: rgba(0, 0, 0, 0.3);
    }

    .pill strong {
      color: var(--accent);
    }

    .days-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
      gap: 14px;
      margin-top: 20px;
    }

    .day-card {
      background: var(--card-bg);
      border-radius: 16px;
      padding: 10px 12px;
      border: 1px solid var(--border);
      box-shadow: 0 10px 22px rgba(0, 0, 0, 0.45);
      font-size: 0.9rem;
      color: var(--muted);
    }

    .day-header {
      display: flex;
      justify-content: space-between;
      align-items: baseline;
      margin-bottom: 4px;
    }

    .day-name {
      font-size: 0.9rem;
      text-transform: uppercase;
      letter-spacing: 0.08em;
    }

    .day-tag {
      font-size: 0.75rem;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: var(--accent);
    }

    .label {
      font-size: 0.75rem;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: var(--muted);
      margin-top: 4px;
      margin-bottom: 2px;
    }

    .day-card p {
      margin: 3px 0 5px;
    }

    .bullet-list {
      padding-left: 16px;
      margin: 2px 0 4px;
    }

    .bullet-list li {
      margin-bottom: 3px;
    }

    .ritual {
      margin-top: 4px;
      padding: 5px 7px;
      border-radius: 10px;
      border: 1px dashed var(--border);
      background: rgba(0, 0, 0, 0.25);
      font-size: 0.86rem;
    }

    .ritual strong {
      color: var(--accent);
    }

    .do-avoid {
      display: flex;
      gap: 8px;
      margin-top: 4px;
      font-size: 0.8rem;
    }

    .do-avoid div {
      flex: 1;
    }

    .do-avoid b {
      display: block;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      font-size: 0.7rem;
      margin-bottom: 1px;
    }

    @media (max-width: 720px) {
      h1 {
        font-size: 1.4rem;
      }
    }
  </style>
</head>
<body>
  <div class="page">
    <header>
      <a href="../index.php" class="back-link">← Back to Home</a>
      <h1>Week 4 • January 22–31, 2026</h1>
      <div class="subtitle">
        Laying Foundations • Building systems and support structures for the year’s expansion.
      </div>
      <div class="week-meta">
        <div class="pill"><strong>Week Focus:</strong> Foundations, community threads, and month-end closure.</div>
        <div class="pill"><strong>Best Use:</strong> System-building, gentle networking, money clarity and end-of-month rituals.</div>
      </div>
    </header>

    <section class="days-grid">
      
      <article class="day-card">
        <div class="day-header">
          <div class="day-name">Thu • January 22</div>
          <div class="day-tag">Foundation Focus</div>
        </div>
        <div class="label">Emotional</div>
        <p>Emotions lean practical—you’re more willing to do unglamorous work that supports long-term freedom.</p>
        <div class="label">Spiritual</div>
        <p>Spirit blesses grounded efforts today; bricks laid now will support expansion later in the year.</p>
        <div class="label">Financial</div>
        <p>Good for basic systems: budgeting, tracking, templates, and workflows.</p>
        <div class="ritual">
          <strong>Ritual:</strong> Choose one foundational piece (budget sheet, tracking doc, template) and create or update it.
        </div>
        <div class="do-avoid">
          <div>
            <b>DO</b>
            <ul class="bullet-list">
              <li>Invest time in tools that will save future you energy.</li><li>Keep your focus on stability, not perfection.</li>
            </ul>
          </div>
          <div>
            <b>AVOID</b>
            <ul class="bullet-list">
              <li>Putting off foundational work “until later.”</li><li>Overcomplicating systems so you resist using them.</li>
            </ul>
          </div>
        </div>
      </article>
    

      <article class="day-card">
        <div class="day-header">
          <div class="day-name">Fri • January 23</div>
          <div class="day-tag">Community Threads</div>
        </div>
        <div class="label">Emotional</div>
        <p>You may feel a pull toward people who “get it” and are moving in similar directions.</p>
        <div class="label">Spiritual</div>
        <p>Your soul is reminding you that your expansion path is easier with the right co-travelers.</p>
        <div class="label">Financial</div>
        <p>Good day for identifying communities, groups, or networks you want to engage more with this year.</p>
        <div class="ritual">
          <strong>Ritual:</strong> List three spaces (online or offline) where aligned people gather, and take one small step toward engaging.
        </div>
        <div class="do-avoid">
          <div>
            <b>DO</b>
            <ul class="bullet-list">
              <li>Follow the trail of genuine resonance.</li><li>Introduce yourself or share a small win where it feels safe.</li>
            </ul>
          </div>
          <div>
            <b>AVOID</b>
            <ul class="bullet-list">
              <li>Forcing yourself into spaces that feel off.</li><li>Assuming you have to do everything alone.</li>
            </ul>
          </div>
        </div>
      </article>
    

      <article class="day-card">
        <div class="day-header">
          <div class="day-name">Sat • January 24</div>
          <div class="day-tag">Restorative Day</div>
        </div>
        <div class="label">Emotional</div>
        <p>You might feel a natural slowdown after a practical push; let your emotions catch up.</p>
        <div class="label">Spiritual</div>
        <p>Spirit asks you to balance building with receiving—rest is part of the equation.</p>
        <div class="label">Financial</div>
        <p>Minimal money/work focus; simply ensure bills and essentials are on track.</p>
        <div class="ritual">
          <strong>Ritual:</strong> Choose one purely restorative activity and give it your full presence for at least 30 minutes.
        </div>
        <div class="do-avoid">
          <div>
            <b>DO</b>
            <ul class="bullet-list">
              <li>Let your mind wander without a productivity agenda.</li><li>Tune into what actually feels nourishing vs. numbing.</li>
            </ul>
          </div>
          <div>
            <b>AVOID</b>
            <ul class="bullet-list">
              <li>Filling the day with errands to avoid stillness.</li><li>Feeling guilty for doing “nothing.”</li>
            </ul>
          </div>
        </div>
      </article>
    

      <article class="day-card">
        <div class="day-header">
          <div class="day-name">Sun • January 25</div>
          <div class="day-tag">Vision Revisit</div>
        </div>
        <div class="label">Emotional</div>
        <p>Emotionally, you may feel ready to revisit your 2026 vision with more clarity than on January 1.</p>
        <div class="label">Spiritual</div>
        <p>Your inner guidance now has more data from lived experience this month—refining your vision is supported.</p>
        <div class="label">Financial</div>
        <p>Light financial or work planning: align your next month with what you’ve learned this month.</p>
        <div class="ritual">
          <strong>Ritual:</strong> Reread any intentions or letters you wrote at the start of the year and update them to match who you are now.
        </div>
        <div class="do-avoid">
          <div>
            <b>DO</b>
            <ul class="bullet-list">
              <li>Adapt your vision to your current truth.</li><li>Let your goals feel more precise and embodied.</li>
            </ul>
          </div>
          <div>
            <b>AVOID</b>
            <ul class="bullet-list">
              <li>Clinging to an outdated vision from obligation.</li><li>Assuming change means you “failed” at earlier plans.</li>
            </ul>
          </div>
        </div>
      </article>
    

      <article class="day-card">
        <div class="day-header">
          <div class="day-name">Mon • January 26</div>
          <div class="day-tag">Skill & Craft</div>
        </div>
        <div class="label">Emotional</div>
        <p>You may feel drawn to deepen your actual skills and craft—not just strategy or planning.</p>
        <div class="label">Spiritual</div>
        <p>Spirit reminds you that mastery is part of your expansion; your gifts deserve refinement.</p>
        <div class="label">Financial</div>
        <p>Good for study, practice, training, or improving systems that support your work quality.</p>
        <div class="ritual">
          <strong>Ritual:</strong> Dedicate one focused block today to skill-building or deliberate practice in one key area.
        </div>
        <div class="do-avoid">
          <div>
            <b>DO</b>
            <ul class="bullet-list">
              <li>Prioritize depth over breadth.</li><li>Notice how strengthening your craft boosts confidence.</li>
            </ul>
          </div>
          <div>
            <b>AVOID</b>
            <ul class="bullet-list">
              <li>Jumping between five new learning topics.</li><li>Comparing your skill level harshly to others.</li>
            </ul>
          </div>
        </div>
      </article>
    

      <article class="day-card">
        <div class="day-header">
          <div class="day-name">Tue • January 27</div>
          <div class="day-tag">Money Clarity</div>
        </div>
        <div class="label">Emotional</div>
        <p>Emotions around money may surface—anxiety, hope, or both. Clarity calms the system.</p>
        <div class="label">Spiritual</div>
        <p>Spirit supports looking at money as neutral information, not moral judgment.</p>
        <div class="label">Financial</div>
        <p>Ideal for a full money check-in: income, expenses, debts, and near-term opportunities.</p>
        <div class="ritual">
          <strong>Ritual:</strong> Do a simple money date: open your accounts, list key numbers, and ask, “What direction do I want these to move?”
        </div>
        <div class="do-avoid">
          <div>
            <b>DO</b>
            <ul class="bullet-list">
              <li>Treat money as a tool and feedback mechanism.</li><li>Identify one concrete money action for early February.</li>
            </ul>
          </div>
          <div>
            <b>AVOID</b>
            <ul class="bullet-list">
              <li>Avoiding numbers out of fear.</li><li>Spending impulsively to soothe stress.</li>
            </ul>
          </div>
        </div>
      </article>
    

      <article class="day-card">
        <div class="day-header">
          <div class="day-name">Wed • January 28</div>
          <div class="day-tag">Boundary Reinforcement</div>
        </div>
        <div class="label">Emotional</div>
        <p>Emotionally, you may feel where your boundaries have already been tested this year.</p>
        <div class="label">Spiritual</div>
        <p>Your soul prompts you to reinforce what you set earlier in the month so it becomes second nature.</p>
        <div class="label">Financial</div>
        <p>Good for fine-tuning your schedule, communication norms, and response times in work and life.</p>
        <div class="ritual">
          <strong>Ritual:</strong> Write down 3–5 “house rules” for your energy—how you respond, what you accept, and what you decline.
        </div>
        <div class="do-avoid">
          <div>
            <b>DO</b>
            <ul class="bullet-list">
              <li>Communicate at least one boundary clearly to someone else.</li><li>Stand by a limit you’ve already set.</li>
            </ul>
          </div>
          <div>
            <b>AVOID</b>
            <ul class="bullet-list">
              <li>Backtracking on boundaries to avoid discomfort.</li><li>Keeping rules only in your head.</li>
            </ul>
          </div>
        </div>
      </article>
    

      <article class="day-card">
        <div class="day-header">
          <div class="day-name">Thu • January 29</div>
          <div class="day-tag">Subtle Wins</div>
        </div>
        <div class="label">Emotional</div>
        <p>Emotionally calmer; you’re able to notice subtler changes you’d have missed in a rush.</p>
        <div class="label">Spiritual</div>
        <p>Spirit points out the small ways reality is already rearranging around your new choices.</p>
        <div class="label">Financial</div>
        <p>Light money/work day—great for tying up loose ends and acknowledging progress.</p>
        <div class="ritual">
          <strong>Ritual:</strong> List “quiet wins” of January: things that didn’t explode into visibility but still matter.
        </div>
        <div class="do-avoid">
          <div>
            <b>DO</b>
            <ul class="bullet-list">
              <li>Validate internal shifts as much as external ones.</li><li>Let subtle evidence boost your faith in the process.</li>
            </ul>
          </div>
          <div>
            <b>AVOID</b>
            <ul class="bullet-list">
              <li>Waiting for huge breakthroughs to feel successful.</li><li>Ignoring how different you already feel inside.</li>
            </ul>
          </div>
        </div>
      </article>
    

      <article class="day-card">
        <div class="day-header">
          <div class="day-name">Fri • January 30</div>
          <div class="day-tag">Closing Loops</div>
        </div>
        <div class="label">Emotional</div>
        <p>Emotionally, you feel satisfaction when you finish what you started earlier this month.</p>
        <div class="label">Spiritual</div>
        <p>Your higher self wants you to carry fewer loose ends into February.</p>
        <div class="label">Financial</div>
        <p>Good for completing tasks, sending last emails, and clearing lingering admin.</p>
        <div class="ritual">
          <strong>Ritual:</strong> Choose three open loops (tasks, messages, decisions) and close at least two today.
        </div>
        <div class="do-avoid">
          <div>
            <b>DO</b>
            <ul class="bullet-list">
              <li>Finish what you reasonably can.</li><li>Acknowledge yourself for completion, not just initiation.</li>
            </ul>
          </div>
          <div>
            <b>AVOID</b>
            <ul class="bullet-list">
              <li>Starting new projects today instead of finishing old ones.</li><li>Leaving “almost done” tasks hanging.</li>
            </ul>
          </div>
        </div>
      </article>
    

      <article class="day-card">
        <div class="day-header">
          <div class="day-name">Sat • January 31</div>
          <div class="day-tag">Month-End Ritual</div>
        </div>
        <div class="label">Emotional</div>
        <p>Emotions are reflective; you’re aware of how different the end of January feels from the start.</p>
        <div class="label">Spiritual</div>
        <p>Spirit invites you to seal January with gratitude and intention so February starts clean.</p>
        <div class="label">Financial</div>
        <p>Perfect for a simple end-of-month ritual and a brief financial check-in.</p>
        <div class="ritual">
          <strong>Ritual:</strong> Light a candle, review January’s highlights and lessons, thank the month, and write one intention for February.
        </div>
        <div class="do-avoid">
          <div>
            <b>DO</b>
            <ul class="bullet-list">
              <li>Consciously close this chapter instead of drifting past it.</li><li>Let gratitude amplify what you want more of.</li>
            </ul>
          </div>
          <div>
            <b>AVOID</b>
            <ul class="bullet-list">
              <li>Rushing past the month without reflection.</li><li>Carrying unfinished emotional narratives into February.</li>
            </ul>
          </div>
        </div>
      </article>
    
    </section>
  </div>
</body>
</html>
