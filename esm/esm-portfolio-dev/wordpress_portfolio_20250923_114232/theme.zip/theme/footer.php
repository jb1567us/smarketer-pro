
        </main>
        
        <footer class="site-footer">
            <div class="footer-content">
                <p>&copy; <?php echo date('Y'); ?> Elliot Spencer Morgan. All rights reserved.</p>
            </div>
        </footer>
        
        <?php wp_footer(); ?>
        </body>
        </html>
        