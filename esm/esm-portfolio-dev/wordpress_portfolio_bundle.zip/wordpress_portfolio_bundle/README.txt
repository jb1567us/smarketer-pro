# WordPress Portfolio Bundle

This bundle contains a corrected Python script to scrape SaatchiArt pages and generate a WordPress WXR export + a minimal theme that won't throw `get_header()` errors.

## Files
- `wordpress_portfolio_generator.py` — run with Python 3.10+
- Generated output will appear in a folder named like `wordpress_portfolio_YYYYMMDD_HHMMSS/`

## Quickstart
```bash
python3 wordpress_portfolio_generator.py
```
Then follow the `IMPORT_INSTRUCTIONS.md` inside the generated folder.
