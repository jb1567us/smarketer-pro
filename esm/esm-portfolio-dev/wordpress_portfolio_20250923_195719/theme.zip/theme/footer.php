
        </main>
        
        <footer class="site-footer">
            <div class="container">
                <p>&copy; <?php echo date('Y'); ?> Elliot Spencer Morgan. All rights reserved.</p>
            </div>
        </footer>
        
        <?php wp_footer(); ?>
        </body>
        </html>
        