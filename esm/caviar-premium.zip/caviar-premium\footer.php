
    <footer id="colophon" class="site-footer" style="text-align:center; padding: 2rem; border-top: 1px solid #eee; margin-top: 2rem;">
        <div class="site-info">
            &copy; <?php echo date( 'Y' ); ?> <?php bloginfo( 'name' ); ?>. All rights reserved.
        </div>
    </footer>

    <?php wp_footer(); ?>
</body>
</html>
