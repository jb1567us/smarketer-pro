
import React, { useState } from 'react';
import { RoomAnalysis, RedesignStyle } from '../types';

interface AnalysisViewProps {
  analysis: RoomAnalysis;
  onReset: () => void;
  onGenerateRedesign: (style: string) => void;
  onGenerateVideo: (style: string) => void;
  isLoadingRedesign: boolean;
  isLoadingVideo: boolean;
  originalImage: string;
}

export const AnalysisView: React.FC<AnalysisViewProps> = ({ 
  analysis, 
  onReset, 
  onGenerateRedesign,
  onGenerateVideo,
  isLoadingRedesign,
  isLoadingVideo,
  originalImage
}) => {
  const [selectedStyleIndex, setSelectedStyleIndex] = useState(0);
  const selectedStyle = analysis.redesignOptions[selectedStyleIndex];
  const isVideo = originalImage.includes('video');

  const getClutterColor = (level: string) => {
    switch (level) {
      case 'Low': return 'bg-emerald-100 text-emerald-700';
      case 'Medium': return 'bg-amber-100 text-amber-700';
      case 'High': return 'bg-orange-100 text-orange-700';
      case 'Critical': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-4xl font-bold mb-2">Space Analysis</h1>
          <p className="text-slate-500">Identified as a <span className="font-semibold">{analysis.roomType}</span></p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button 
            onClick={onReset}
            className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors border bg-white"
          >
            Start Over
          </button>
          <button 
            onClick={() => onGenerateRedesign(selectedStyle.style)}
            disabled={isLoadingRedesign || isLoadingVideo}
            className="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200 disabled:opacity-50 flex items-center gap-2"
          >
            {isLoadingRedesign ? 'Visualizing...' : 'Photo Redesign'}
          </button>
          <button 
            onClick={() => onGenerateVideo(selectedStyle.style)}
            disabled={isLoadingRedesign || isLoadingVideo}
            className="px-6 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-lg hover:from-purple-700 hover:to-indigo-700 transition-colors shadow-lg shadow-purple-200 disabled:opacity-50 flex items-center gap-2"
          >
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M2 6a2 2 0 012-2h6a2 2 0 012 2v8a2 2 0 01-2 2H4a2 2 0 01-2-2V6zM14.553 7.106A1 1 0 0014 8v4a1 1 0 00.553.894l2 1A1 1 0 0018 13V7a1 1 0 00-1.447-.894l-2 1z" /></svg>
            Video Walkthrough
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="space-y-6">
          <div className="rounded-2xl overflow-hidden shadow-md border bg-white p-2">
            {isVideo ? (
              <video src={originalImage} className="w-full aspect-square object-cover rounded-xl" autoPlay loop muted playsInline />
            ) : (
              <img src={originalImage} alt="Original" className="w-full aspect-square object-cover rounded-xl" />
            )}
          </div>
          
          <div className={`p-4 rounded-xl flex items-center justify-between ${getClutterColor(analysis.currentClutterLevel)}`}>
            <span className="font-medium">Clutter Level</span>
            <span className="text-lg font-bold">{analysis.currentClutterLevel}</span>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-sm border space-y-4">
            <h3 className="font-bold text-lg flex items-center gap-2">
               <svg className="w-5 h-5 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
               Top Issues
            </h3>
            <ul className="space-y-3">
              {analysis.keyIssues.map((issue, idx) => (
                <li key={idx} className="flex gap-3 text-sm text-slate-600">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 mt-1.5 shrink-0" />
                  {issue}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="md:col-span-2 space-y-6">
          <div className="bg-white p-6 rounded-2xl shadow-sm border">
            <h3 className="font-bold text-xl mb-4 border-b pb-2">Decluttering Strategy</h3>
            <div className="space-y-4">
              {analysis.declutterSteps.map((step, idx) => (
                <div key={idx} className="flex items-start gap-4 group">
                  <div className="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center text-slate-400 font-bold shrink-0 border group-hover:bg-indigo-50 group-hover:text-indigo-500 transition-colors">
                    {idx + 1}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="font-semibold text-slate-800">{step.task}</h4>
                      <div className="flex gap-2 text-[10px] uppercase font-bold">
                        <span className={`px-2 py-0.5 rounded ${step.priority === 'High' ? 'bg-red-50 text-red-600' : 'bg-blue-50 text-blue-600'}`}>
                          {step.priority} Priority
                        </span>
                        <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-500">
                          {step.estimatedTime}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gradient-to-br from-indigo-50 to-purple-50 p-6 rounded-2xl border border-indigo-100 space-y-6">
            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-xl">Redesign Options</h3>
                <div className="flex gap-2">
                  {selectedStyle.colorPalette.map((color, i) => (
                    <div 
                      key={i} 
                      className="w-6 h-6 rounded-full border border-white shadow-sm" 
                      style={{ backgroundColor: color }}
                      title={color}
                    />
                  ))}
                </div>
              </div>

              {/* Style Selection Tabs */}
              <div className="grid grid-cols-3 gap-2">
                {analysis.redesignOptions.map((opt, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedStyleIndex(idx)}
                    className={`px-3 py-3 rounded-xl border text-xs font-bold transition-all ${
                      selectedStyleIndex === idx 
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-100' 
                        : 'bg-white text-slate-500 border-slate-200 hover:border-indigo-300'
                    }`}
                  >
                    {opt.style}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4 animate-in fade-in slide-in-from-left-2 duration-300">
              <div className="bg-white/70 p-5 rounded-2xl shadow-sm border border-indigo-50 backdrop-blur-md">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center text-white">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z" /></svg>
                  </div>
                  <div>
                    <span className="text-xs uppercase tracking-widest text-slate-500 font-bold block">Selected Style</span>
                    <h4 className="text-xl font-bold text-indigo-900">{selectedStyle.style}</h4>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Key Characteristics</h5>
                    <div className="flex flex-wrap gap-2">
                      {selectedStyle.styleCharacteristics.map((char, i) => (
                        <span key={i} className="px-3 py-1 bg-indigo-50 text-indigo-700 text-xs font-semibold rounded-full border border-indigo-100">
                          {char}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">How to achieve this look</h5>
                    <p className="text-sm text-slate-700 leading-relaxed italic border-l-2 border-indigo-200 pl-3">
                      {selectedStyle.howToAchieve}
                    </p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-white/60 p-4 rounded-xl backdrop-blur-sm">
                  <span className="text-xs uppercase tracking-wider text-slate-500 font-bold block mb-1">Layout & Flow</span>
                  <p className="text-sm text-slate-700 leading-relaxed">{selectedStyle.layoutChanges}</p>
                </div>
                <div className="bg-white/60 p-4 rounded-xl backdrop-blur-sm">
                  <span className="text-xs uppercase tracking-wider text-slate-500 font-bold block mb-1">Lighting Strategy</span>
                  <p className="text-sm text-slate-700 leading-relaxed">{selectedStyle.lightingTips}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
