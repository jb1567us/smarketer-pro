
import React from 'react';

interface RedesignModalProps {
  redesignUrl: string;
  originalUrl: string;
  onClose: () => void;
}

export const RedesignModal: React.FC<RedesignModalProps> = ({ redesignUrl, originalUrl, onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/90 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="bg-white w-full max-w-5xl rounded-3xl overflow-hidden shadow-2xl relative">
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 z-10 bg-white/10 hover:bg-white/20 text-white rounded-full p-2 backdrop-blur-md"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-2 bg-black">
          <div className="relative group">
            <span className="absolute top-4 left-4 z-10 bg-black/50 text-white text-xs px-2 py-1 rounded font-bold uppercase">Before</span>
            <img src={originalUrl} className="w-full h-[40vh] lg:h-[70vh] object-cover opacity-60 group-hover:opacity-100 transition-opacity" alt="Before" />
          </div>
          <div className="relative">
            <span className="absolute top-4 left-4 z-10 bg-indigo-600 text-white text-xs px-2 py-1 rounded font-bold uppercase">AI Vision: Optimized</span>
            <img src={redesignUrl} className="w-full h-[40vh] lg:h-[70vh] object-cover" alt="After Redesign" />
          </div>
        </div>

        <div className="p-8 text-center bg-white space-y-4">
          <h2 className="text-3xl font-bold">Your Transformation</h2>
          <p className="text-slate-500 max-w-2xl mx-auto italic">
            "This visualization shows how your space could look by removing clutter and optimizing for the {window.innerWidth < 640 ? 'recommended' : 'AI-suggested'} design style."
          </p>
          <button 
            onClick={onClose}
            className="px-8 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200"
          >
            I'm Ready to Start
          </button>
        </div>
      </div>
    </div>
  );
};
