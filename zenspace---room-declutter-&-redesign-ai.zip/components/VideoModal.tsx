
import React from 'react';

interface VideoModalProps {
  videoUrl: string;
  onClose: () => void;
}

export const VideoModal: React.FC<VideoModalProps> = ({ videoUrl, onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/90 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="bg-black w-full max-w-5xl aspect-video rounded-3xl overflow-hidden shadow-2xl relative">
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 z-10 bg-white/10 hover:bg-white/20 text-white rounded-full p-2 backdrop-blur-md"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
        </button>

        <video 
          src={videoUrl} 
          className="w-full h-full object-contain" 
          autoPlay 
          controls 
          loop
        />
        
        <div className="absolute bottom-6 left-6 right-6 text-center pointer-events-none">
          <p className="text-white/70 text-sm drop-shadow-lg font-medium">AI-Generated Visual Walkthrough</p>
        </div>
      </div>
    </div>
  );
};
