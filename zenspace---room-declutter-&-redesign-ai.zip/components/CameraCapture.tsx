
import React, { useRef, useState, useEffect } from 'react';

interface CameraCaptureProps {
  onCapture: (base64: string, type: 'image' | 'video', mimeType: string) => void;
  onClose: () => void;
}

export const CameraCapture: React.FC<CameraCaptureProps> = ({ onCapture, onClose }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [chunks, setChunks] = useState<Blob[]>([]);

  useEffect(() => {
    startCamera();
    return () => stopCamera();
  }, []);

  useEffect(() => {
    let interval: number;
    if (isRecording) {
      interval = window.setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRecording]);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' },
        audio: false 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      setError('Could not access camera. Please check permissions.');
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach(track => track.stop());
    }
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      if (context) {
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        context.drawImage(videoRef.current, 0, 0);
        const dataUrl = canvasRef.current.toDataURL('image/jpeg');
        onCapture(dataUrl.split(',')[1], 'image', 'image/jpeg');
      }
    }
  };

  const startRecording = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      const mediaRecorder = new MediaRecorder(stream, { mimeType: 'video/webm' });
      mediaRecorderRef.current = mediaRecorder;
      const localChunks: Blob[] = [];
      
      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) localChunks.push(e.data);
      };

      mediaRecorder.onstop = async () => {
        const blob = new Blob(localChunks, { type: 'video/webm' });
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64 = (reader.result as string).split(',')[1];
          onCapture(base64, 'video', 'video/webm');
        };
        reader.readAsDataURL(blob);
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingTime(0);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col">
      <div className="flex justify-between items-center p-4">
        <h2 className="text-white text-lg font-medium">Capture Your Space</h2>
        <button onClick={onClose} className="text-white p-2">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>

      <div className="flex-1 relative flex items-center justify-center bg-zinc-900">
        {error ? (
          <p className="text-red-400 text-center px-4">{error}</p>
        ) : (
          <>
            <video 
              ref={videoRef} 
              autoPlay 
              playsInline 
              className="w-full h-full object-cover max-h-[70vh]"
            />
            {isRecording && (
              <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-red-600 text-white px-4 py-1 rounded-full font-bold animate-pulse flex items-center gap-2">
                <span className="w-2 h-2 bg-white rounded-full"></span>
                {recordingTime}s
              </div>
            )}
          </>
        )}
      </div>

      <div className="p-8 flex justify-center items-center gap-8 bg-black">
        <button 
          onClick={capturePhoto}
          disabled={isRecording}
          className="flex flex-col items-center gap-2 text-white/70 hover:text-white disabled:opacity-30"
        >
          <div className="w-16 h-16 bg-white rounded-full border-4 border-zinc-400 active:scale-95 transition-transform" />
          <span className="text-xs font-bold uppercase">Photo</span>
        </button>

        <button 
          onClick={isRecording ? stopRecording : startRecording}
          className="flex flex-col items-center gap-2 text-white"
        >
          <div className={`w-16 h-16 rounded-full border-4 border-zinc-400 flex items-center justify-center active:scale-95 transition-transform ${isRecording ? 'bg-white' : 'bg-red-600'}`}>
            {isRecording ? (
              <div className="w-6 h-6 bg-red-600 rounded-sm" />
            ) : (
              <div className="w-6 h-6 bg-white rounded-full" />
            )}
          </div>
          <span className="text-xs font-bold uppercase">{isRecording ? 'Stop' : 'Video'}</span>
        </button>
      </div>
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
};
