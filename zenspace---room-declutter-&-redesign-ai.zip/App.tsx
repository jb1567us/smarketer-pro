
import React, { useState, useCallback } from 'react';
import { analyzeRoom, generateRedesignPreview, generateVideoWalkthrough } from './services/geminiService';
import { RoomAnalysis, MediaPreview } from './types';
import { CameraCapture } from './components/CameraCapture';
import { AnalysisView } from './components/AnalysisView';
import { RedesignModal } from './components/RedesignModal';
import { VideoModal } from './components/VideoModal';

const App: React.FC = () => {
  const [media, setMedia] = useState<MediaPreview | null>(null);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<RoomAnalysis | null>(null);
  const [redesignUrl, setRedesignUrl] = useState<string | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [isGeneratingRedesign, setIsGeneratingRedesign] = useState(false);
  const [isGeneratingVideo, setIsGeneratingVideo] = useState(false);
  const [videoProgress, setVideoProgress] = useState("");
  const [error, setError] = useState<string | null>(null);

  const handleCapture = useCallback(async (base64: string, type: 'image' | 'video', mimeType: string) => {
    setMedia({ url: `data:${mimeType};base64,${base64}`, base64, type, mimeType });
    setIsCameraOpen(false);
    setError(null);
    setIsAnalyzing(true);
    
    try {
      const result = await analyzeRoom(base64, mimeType);
      setAnalysis(result);
    } catch (err) {
      console.error(err);
      setError('Failed to analyze room. Please try again with a clearer capture.');
      setMedia(null);
    } finally {
      setIsAnalyzing(false);
    }
  }, []);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = (reader.result as string).split(',')[1];
        const type = file.type.startsWith('video') ? 'video' : 'image';
        handleCapture(base64, type, file.type);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGenerateRedesign = async (style: string) => {
    if (!media || !analysis) return;
    setIsGeneratingRedesign(true);
    try {
      const url = await generateRedesignPreview(media.base64, style);
      setRedesignUrl(url);
    } catch (err) {
      console.error(err);
      setError('Visual redesign failed. Try again shortly.');
    } finally {
      setIsGeneratingRedesign(false);
    }
  };

  const handleGenerateVideo = async (style: string) => {
    if (!media || !analysis) return;

    const hasKey = await (window as any).aistudio?.hasSelectedApiKey();
    if (!hasKey) {
      await (window as any).aistudio?.openSelectKey();
    }

    setIsGeneratingVideo(true);
    setVideoProgress("Connecting to design engine...");
    try {
      const url = await generateVideoWalkthrough(media.base64, style, setVideoProgress);
      setVideoUrl(url);
    } catch (err: any) {
      console.error(err);
      if (err.message?.includes("Requested entity was not found")) {
        await (window as any).aistudio?.openSelectKey();
      }
      setError('Video generation failed. Ensure you have a paid API key selected.');
    } finally {
      setIsGeneratingVideo(false);
      setVideoProgress("");
    }
  };

  const reset = () => {
    setMedia(null);
    setAnalysis(null);
    setRedesignUrl(null);
    setVideoUrl(null);
    setError(null);
  };

  if (isAnalyzing) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-8 bg-white">
        <div className="w-24 h-24 relative mb-8">
          <div className="absolute inset-0 border-4 border-indigo-100 rounded-full"></div>
          <div className="absolute inset-0 border-4 border-indigo-600 rounded-full border-t-transparent animate-spin"></div>
        </div>
        <h2 className="text-3xl font-bold mb-4 animate-pulse">Analyzing Your Space</h2>
        <div className="max-w-md text-center space-y-2">
          <p className="text-slate-500">{media?.type === 'video' ? 'Processing video sequence...' : 'Scanning for clutter patterns...'}</p>
          <p className="text-slate-500">Generating organizational strategies...</p>
          <p className="text-slate-500">Curating style recommendations...</p>
        </div>
      </div>
    );
  }

  if (isGeneratingVideo) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-8 bg-slate-900 text-white">
        <div className="w-32 h-32 relative mb-12">
          <div className="absolute inset-0 border-8 border-white/10 rounded-full"></div>
          <div className="absolute inset-0 border-8 border-indigo-500 rounded-full border-t-transparent animate-spin"></div>
          <div className="absolute inset-4 border-4 border-purple-500 rounded-full border-b-transparent animate-[spin_3s_linear_infinite]"></div>
        </div>
        <h2 className="text-4xl font-bold mb-6 text-center bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">
          Crafting Your Cinematic Vision
        </h2>
        <div className="max-w-md text-center space-y-4">
          <p className="text-xl font-medium text-white/90">{videoProgress}</p>
          <div className="p-4 bg-white/5 rounded-2xl border border-white/10">
            <p className="text-sm text-white/60">
              Video generation can take up to 2 minutes. We're rendering every pixel of your future home.
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (analysis && media) {
    return (
      <div className="min-h-screen bg-[#F9FAFB]">
        <AnalysisView 
          analysis={analysis} 
          onReset={reset}
          originalImage={media.url}
          onGenerateRedesign={handleGenerateRedesign}
          onGenerateVideo={handleGenerateVideo}
          isLoadingRedesign={isGeneratingRedesign}
          isLoadingVideo={isGeneratingVideo}
        />
        {redesignUrl && (
          <RedesignModal 
            redesignUrl={redesignUrl} 
            originalUrl={media.url} 
            onClose={() => setRedesignUrl(null)} 
          />
        )}
        {videoUrl && (
          <VideoModal 
            videoUrl={videoUrl} 
            onClose={() => setVideoUrl(null)} 
          />
        )}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 selection:bg-indigo-100">
      <nav className="p-6 flex justify-between items-center max-w-6xl mx-auto">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-bold text-xl italic">Z</div>
          <span className="text-2xl font-bold tracking-tight">ZenSpace</span>
        </div>
      </nav>

      <main className="max-w-6xl mx-auto px-6 py-12 md:py-24 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <div className="space-y-8">
          <div className="space-y-4">
            <h1 className="text-6xl md:text-7xl font-bold leading-tight">
              Reclaim your <span className="text-indigo-600">calm</span>.
            </h1>
            <p className="text-xl text-slate-600 leading-relaxed max-w-lg">
              Shoot a quick video or photo of your messy room. Our AI identifies clutter, understands your layout, and visualizes a beautiful, organized transformation.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 pt-4">
            <button 
              onClick={() => setIsCameraOpen(true)}
              className="px-8 py-4 bg-indigo-600 text-white rounded-2xl font-bold text-lg hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 flex items-center justify-center gap-2"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
              Open Camera
            </button>
            <label className="px-8 py-4 bg-white text-slate-800 border-2 border-slate-200 rounded-2xl font-bold text-lg hover:border-indigo-600 hover:text-indigo-600 transition-all cursor-pointer flex items-center justify-center gap-2">
              <input 
                type="file" 
                className="hidden" 
                accept="image/*,video/*" 
                onChange={handleFileUpload}
              />
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
              Upload Photo/Video
            </label>
          </div>
          
          {error && (
            <div className="p-4 bg-red-50 text-red-600 rounded-xl border border-red-100 text-sm">
              {error}
            </div>
          )}
        </div>

        <div className="relative">
          <div className="absolute -inset-4 bg-indigo-100/50 rounded-full blur-3xl opacity-50 -z-10"></div>
          <div className="rounded-3xl overflow-hidden shadow-2xl border-8 border-white transform rotate-2">
            <img 
              src="https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&q=80&w=800" 
              alt="Room example" 
              className="w-full h-auto grayscale-[0.2]"
            />
          </div>
        </div>
      </main>

      {isCameraOpen && (
        <CameraCapture 
          onCapture={handleCapture} 
          onClose={() => setIsCameraOpen(false)} 
        />
      )}
    </div>
  );
};

export default App;
