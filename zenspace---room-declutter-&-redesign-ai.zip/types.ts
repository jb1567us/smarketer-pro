
export interface RedesignStyle {
  style: string;
  styleCharacteristics: string[];
  howToAchieve: string;
  colorPalette: string[];
  layoutChanges: string;
  lightingTips: string;
}

export interface RoomAnalysis {
  roomType: string;
  currentClutterLevel: 'Low' | 'Medium' | 'High' | 'Critical';
  keyIssues: string[];
  declutterSteps: {
    task: string;
    priority: 'High' | 'Medium' | 'Low';
    estimatedTime: string;
  }[];
  organizationHacks: {
    title: string;
    description: string;
    productsNeeded?: string[];
  }[];
  redesignOptions: RedesignStyle[];
}

export interface MediaPreview {
  url: string;
  base64: string;
  type: 'image' | 'video';
  mimeType: string;
}
