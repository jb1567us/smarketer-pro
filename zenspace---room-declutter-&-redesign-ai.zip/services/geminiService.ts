
import { GoogleGenAI, Type } from "@google/genai";
import { RoomAnalysis } from "../types";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function analyzeRoom(base64Data: string, mimeType: string): Promise<RoomAnalysis> {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: mimeType,
            data: base64Data,
          },
        },
        {
          text: `Analyze this room ${mimeType.startsWith('video') ? 'video walkthrough' : 'photo'} and provide detailed decluttering, organization, and redesign advice. 
          If it's a video, pay attention to the overall floor layout and spatial flow.
          
          Provide THREE distinct redesign style options (e.g., "Minimalist Zen", "Industrial Loft", "Modern Bohemian", etc.) that would work well for this specific room.
          For each style, provide specific characteristics, an implementation guide, a color palette, and layout/lighting tips.
          
          Return the data in the specified JSON format.`,
        },
      ],
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          roomType: { type: Type.STRING },
          currentClutterLevel: { type: Type.STRING, enum: ['Low', 'Medium', 'High', 'Critical'] },
          keyIssues: { 
            type: Type.ARRAY,
            items: { type: Type.STRING }
          },
          declutterSteps: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                task: { type: Type.STRING },
                priority: { type: Type.STRING, enum: ['High', 'Medium', 'Low'] },
                estimatedTime: { type: Type.STRING }
              },
              required: ['task', 'priority', 'estimatedTime']
            }
          },
          organizationHacks: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                description: { type: Type.STRING },
                productsNeeded: { type: Type.ARRAY, items: { type: Type.STRING } }
              },
              required: ['title', 'description']
            }
          },
          redesignOptions: {
            type: Type.ARRAY,
            minItems: 3,
            maxItems: 3,
            items: {
              type: Type.OBJECT,
              properties: {
                style: { type: Type.STRING },
                styleCharacteristics: { type: Type.ARRAY, items: { type: Type.STRING } },
                howToAchieve: { type: Type.STRING },
                colorPalette: { type: Type.ARRAY, items: { type: Type.STRING } },
                layoutChanges: { type: Type.STRING },
                lightingTips: { type: Type.STRING }
              },
              required: ['style', 'styleCharacteristics', 'howToAchieve', 'colorPalette', 'layoutChanges', 'lightingTips']
            }
          }
        },
        required: ['roomType', 'currentClutterLevel', 'keyIssues', 'declutterSteps', 'organizationHacks', 'redesignOptions']
      },
    },
  });

  return JSON.parse(response.text || '{}') as RoomAnalysis;
}

export async function generateRedesignPreview(base64Image: string, style: string): Promise<string> {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          inlineData: {
            data: base64Image,
            mimeType: 'image/jpeg',
          },
        },
        {
          text: `Redesign this room to be minimalist, clean, and perfectly organized in a ${style} style. Remove all visible clutter, replace messy areas with sleek storage solutions, and harmonize the color palette. Maintain the basic layout but make it look like a high-end interior design magazine photo.`,
        },
      ],
    },
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  
  throw new Error("Failed to generate redesign image");
}

export async function generateVideoWalkthrough(base64Image: string, style: string, onProgress?: (msg: string) => void): Promise<string> {
  const ai = getAI();
  onProgress?.("Initiating AI video sequence...");
  
  let operation = await ai.models.generateVideos({
    model: 'veo-3.1-fast-generate-preview',
    prompt: `A cinematic slow-pan walkthrough of this room, perfectly redesigned in a ${style} style. The room is now immaculate, clutter-free, and beautifully organized with high-end furniture and professional lighting. 4k, smooth motion, interior design showcase.`,
    image: {
      imageBytes: base64Image,
      mimeType: 'image/jpeg',
    },
    config: {
      numberOfVideos: 1,
      resolution: '720p',
      aspectRatio: '16:9'
    }
  });

  const messages = [
    "Analyzing spatial layout...",
    "Removing digital clutter...",
    "Applying high-end textures...",
    "Simulating professional lighting...",
    "Rendering cinematic walkthrough...",
    "Polishing surfaces and organization...",
    "Finalizing visual harmony..."
  ];
  let msgIdx = 0;

  while (!operation.done) {
    onProgress?.(messages[msgIdx % messages.length]);
    msgIdx++;
    await new Promise(resolve => setTimeout(resolve, 10000));
    operation = await ai.operations.getVideosOperation({ operation: operation });
  }

  const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
  if (!downloadLink) throw new Error("Video generation failed.");

  const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
  const blob = await response.blob();
  return URL.createObjectURL(blob);
}
