---
description: test-image-workflow
---

user inputs image requirements
manager talks specs and inputs them into the designer
designer generates an image

<!-- WORKFLOW_STEPS_START

WORKFLOW_STEPS_END -->