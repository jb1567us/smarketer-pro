<?php return array('dependencies' => array(), 'version' => '4898625182f06ab5aae7');
