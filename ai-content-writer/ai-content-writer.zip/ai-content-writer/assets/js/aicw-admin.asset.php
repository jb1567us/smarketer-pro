<?php return array('dependencies' => array(), 'version' => '8ab902009d0faf9cb882');
