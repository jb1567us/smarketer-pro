<?php return array('dependencies' => array(), 'version' => 'c76e272b48ff227408c6');
