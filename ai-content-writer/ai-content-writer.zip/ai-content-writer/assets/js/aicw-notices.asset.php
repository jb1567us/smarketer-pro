<?php return array('dependencies' => array(), 'version' => 'eadf182683e201de3be9');
