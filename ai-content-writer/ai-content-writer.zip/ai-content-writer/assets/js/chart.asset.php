<?php return array('dependencies' => array(), 'version' => 'abd8961d4b33de064352');
